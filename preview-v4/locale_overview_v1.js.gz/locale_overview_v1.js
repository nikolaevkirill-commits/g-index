NRLocale.register([
["Файл передано системі. Збереження файла не означає імпорт у календар; відкрийте його й перевірте подію та нагадування.", "File handed to the system. Saving a file does not import it into a calendar; open it and check the event and reminder.", "Archivo enviado al sistema. Guardarlo no lo importa al calendario; ábrelo y comprueba el evento y el recordatorio.", "Fichier transmis au système. Son enregistrement ne l’importe pas dans le calendrier ; ouvrez-le et vérifiez l’événement et le rappel."],
["Завантаження файла запитано. Перевірте, що файл збережено, потім відкрийте його у календарі.", "File download requested. Check that it was saved, then open it in your calendar.", "Descarga solicitada. Comprueba que el archivo se guardó y ábrelo en tu calendario.", "Téléchargement demandé. Vérifiez que le fichier est enregistré, puis ouvrez-le dans votre calendrier."],
["Передавання файла скасовано.", "File sharing cancelled.", "Se canceló el envío del archivo.", "Partage du fichier annulé."],
['Метод і межі перевірки','Method and verification limits','Método y límites de verificación','Méthode et limites de vérification'],
['Метод розрахунку: ','Calculation method: ','Método de cálculo: ','Méthode de calcul : '],
['Метод розрахунку не підтверджено.','The calculation method is unverified.','El método de cálculo no está verificado.','La méthode de calcul n’est pas vérifiée.'],
['Часова шкала попередня; час переходів потребує перевірки.','The time scale is provisional; transition times need verification.','La escala temporal es provisional; las horas de transición necesitan verificación.','L’échelle de temps est provisoire ; les heures de transition doivent être vérifiées.'],
['Метод розрахунку не підтверджує точність прогнозу особистих подій.','The calculation method does not establish the accuracy of personal event forecasts.','El método de cálculo no confirma la precisión de las predicciones de acontecimientos personales.','La méthode de calcul ne confirme pas la précision des prévisions d’événements personnels.'],
["Джерела та методика", "Sources and method", "Fuentes y método", "Sources et méthode"],
["Оцінка не гарантує результату подій. Для перевірки прогнозу потрібні незалежно зафіксовані спостереження.", "The score does not guarantee event outcomes. Independent observations are needed to validate the forecast.", "La puntuación no garantiza los resultados. Se necesitan observaciones independientes para validar el pronóstico.", "Le score ne garantit pas le résultat des événements. Des observations indépendantes sont nécessaires pour valider les prévisions."],
["Конфіденційність", "Privacy", "Privacidad", "Confidentialité"],
["Умови", "Terms", "Condiciones", "Conditions"],
["Видалення акаунта", "Account deletion", "Eliminar la cuenta", "Suppression du compte"],
["Підтримка", "Support", "Soporte", "Assistance"],
["Правові документи та підтримка", "Legal documents and support", "Documentos legales y soporte", "Documents juridiques et assistance"],
["Дані Kp/Ap — NOAA SWPC; Dst — Kyoto WDC; Sn — SILSO/ROB. Споживча оцінка — автоматичний розрахунок source_formula. Прогностичну точність щодо подій ще не підтверджено.", "Kp/Ap data: NOAA SWPC; Dst: Kyoto WDC; Sn: SILSO/ROB. The consumer score is calculated automatically by source_formula. Predictive accuracy for events has not been established.", "Datos Kp/Ap: NOAA SWPC; Dst: Kyoto WDC; Sn: SILSO/ROB. La puntuación se calcula automáticamente mediante source_formula. La precisión predictiva de los acontecimientos aún no se ha confirmado.", "Données Kp/Ap : NOAA SWPC ; Dst : Kyoto WDC ; Sn : SILSO/ROB. Le score est calculé automatiquement par source_formula. La précision prédictive des événements reste à confirmer."],
[' с.',' seconds.',' segundos.',' secondes.'],
['🟢 Сприятлива','🟢 Favourable','🟢 Favorable','🟢 Favorable'],
['Найближча зміна панчанги: ','Next Panchanga transition: ','Próxima transición de Panchanga: ','Prochaine transition du Panchanga : '],
["Сонце для вашого місця", "Sun at your location", "Sol en tu ubicación", "Soleil à votre emplacement"],
["Визначити моє місце", "Detect my location", "Detectar mi ubicación", "Détecter mon emplacement"],
["Ввести або змінити місце", "Enter or change location", "Introducir o cambiar ubicación", "Saisir ou modifier l’emplacement"],
["Широта (−90…90)", "Latitude (−90…90)", "Latitud (−90…90)", "Latitude (−90…90)"],
["Довгота (−180…180)", "Longitude (−180…180)", "Longitud (−180…180)", "Longitude (−180…180)"],
["Часовий пояс IANA", "IANA time zone", "Zona horaria IANA", "Fuseau horaire IANA"],
["Зберегти місце", "Save location", "Guardar ubicación", "Enregistrer l’emplacement"],
["Видалити місце", "Remove location", "Eliminar ubicación", "Supprimer l’emplacement"],
["Які показники залежать від місця", "Which indicators depend on location", "Qué indicadores dependen de la ubicación", "Quels indicateurs dépendent du lieu"],
["Координати пристрою: ", "Device coordinates: ", "Coordenadas del dispositivo: ", "Coordonnées de l’appareil : "],
["Введені координати: ", "Entered coordinates: ", "Coordenadas introducidas: ", "Coordonnées saisies : "],
["Збережені координати: ", "Saved coordinates: ", "Coordenadas guardadas: ", "Coordonnées enregistrées : "],
["Місце ще не визначено. Координати іншого міста не підставляються.", "Location is not set. Another city’s coordinates are not substituted.", "No se ha establecido la ubicación. No se sustituyen las coordenadas por las de otra ciudad.", "L’emplacement n’est pas défini. Les coordonnées d’une autre ville ne sont pas utilisées."],
["Місце збережено лише на пристрої.", "Location saved only on this device.", "Ubicación guardada solo en este dispositivo.", "Emplacement enregistré uniquement sur cet appareil."],
["Місце діє лише в цьому сеансі.", "Location applies only to this session.", "La ubicación solo se aplica a esta sesión.", "L’emplacement ne s’applique qu’à cette session."],
["Визначаємо місце…", "Detecting location…", "Detectando ubicación…", "Détection de l’emplacement…"],
["Місце недоступне. Введіть координати вручну.", "Location unavailable. Enter coordinates manually.", "Ubicación no disponible. Introduce las coordenadas manualmente.", "Emplacement indisponible. Saisissez les coordonnées manuellement."],
["Некоректні координати або часовий пояс.", "Invalid coordinates or time zone.", "Coordenadas o zona horaria no válidas.", "Coordonnées ou fuseau horaire invalides."],
["Місце видалено.", "Location removed.", "Ubicación eliminada.", "Emplacement supprimé."],
["Не вдалося видалити місце.", "Could not remove location.", "No se pudo eliminar la ubicación.", "Impossible de supprimer l’emplacement."],
["Схід Сонця: ", "Sunrise: ", "Amanecer: ", "Lever du soleil : "],
["Захід Сонця: ", "Sunset: ", "Atardecer: ", "Coucher du soleil : "],
["немає переходу горизонту", "no horizon crossing", "sin cruce del horizonte", "aucun passage de l’horizon"],
["Схід і захід недоступні без коректного місця.", "Sunrise and sunset require a valid location.", "El amanecer y el atardecer requieren una ubicación válida.", "Le lever et le coucher du soleil nécessitent un emplacement valide."],
["Розрахунок для рівного горизонту; погода й рельєф можуть змінити спостережуваний час. Перевірте часовий пояс, особливо в подорожі. Цей блок не змінює бал дня.", "Calculated for a level horizon; weather and terrain can change the observed time. Check the time zone, especially when travelling. This panel does not change the daily score.", "Cálculo para un horizonte plano; el tiempo y el terreno pueden cambiar la hora observada. Comprueba la zona horaria, especialmente al viajar. Este panel no cambia la puntuación diaria.", "Calcul pour un horizon plat ; la météo et le relief peuvent modifier l’heure observée. Vérifiez le fuseau horaire, surtout en voyage. Ce panneau ne modifie pas le score du jour."],
["Kp, Ap, Dst — спільні геомагнітні індекси. Bz і сонячний вітер вимірюються в космосі, Sn — показник сонячної активності; координати їх не перераховують. Локальний K потребує обсерваторії і тут не підключений. Переходи панчанги показано за часом пристрою; Сонце в цьому блоці — за вказаним місцем. Бал і плани залишаються за Києвом.", "Kp, Ap and Dst are shared geomagnetic indices. Bz and solar wind are measured in space, and Sn describes solar activity; coordinates do not recalculate them. Local K requires an observatory and is not connected here. Panchanga transitions use device time; this Sun panel uses the specified location. Scores and plans remain on Kyiv time.", "Kp, Ap y Dst son índices geomagnéticos compartidos. Bz y el viento solar se miden en el espacio y Sn describe la actividad solar; las coordenadas no los recalculan. El K local requiere un observatorio y no está conectado aquí. Las transiciones de Panchanga usan la hora del dispositivo; este panel solar usa la ubicación indicada. Las puntuaciones y los planes siguen con la hora de Kyiv.", "Kp, Ap et Dst sont des indices géomagnétiques communs. Bz et le vent solaire sont mesurés dans l’espace, et Sn décrit l’activité solaire ; les coordonnées ne les recalculent pas. Le K local nécessite un observatoire et n’est pas connecté ici. Les transitions du Panchanga suivent l’heure de l’appareil ; ce panneau solaire utilise le lieu indiqué. Les scores et programmes restent à l’heure de Kyiv."],
['Мова інтерфейсу','Interface language','Idioma de la interfaz','Langue de l’interface'],
['Час переходів і календарна доба — за часовим поясом пристрою. Схід Сонця — в окремому блоці за координатами. Оцінка дня й час планів залишаються за Києвом.','Transition times and the calendar day use your device time zone. Sunrise is in a separate panel using coordinates. The daily score and planned times still use Kyiv time.','Las horas de transición y el día natural usan la zona horaria del dispositivo. El amanecer está en un panel separado que usa coordenadas. La puntuación diaria y los horarios del plan siguen usando la hora de Kyiv.','Les heures de transition et le jour civil suivent le fuseau horaire de l’appareil. Le lever du soleil figure dans un panneau distinct utilisant les coordonnées. Le score du jour et les horaires du programme restent à l’heure de Kyiv.'],
['Додатна · є застереження','Positive · cautions apply','Positiva · hay advertencias','Positive · avec réserves'],
['Експертна правка (PDF) · найвищий пріоритет','Expert correction (PDF) · highest priority','Corrección experta (PDF) · máxima prioridad','Correction experte (PDF) · priorité maximale'],
['Експертна правка · формула джерела окремо:','Expert correction · source formula separately:','Corrección experta · fórmula de la fuente aparte:','Correction experte · formule source à part :'],
['Експертна правка · не прогноз бурі','Expert correction · not a storm forecast','Corrección experta · no es pronóstico de tormenta','Correction experte · pas une prévision d’orage'],
["Попередження NOAA · найближчі три доби", "NOAA alerts · next three days", "Avisos NOAA · próximos tres días", "Alertes NOAA · trois prochains jours"],
["Перевіряємо попередження…", "Checking alerts…", "Comprobando avisos…", "Vérification des alertes…"],
["Свіжих попереджень NOAA зараз немає, тож про бурю не можемо сказати ні «так», ні «ні». Оновимо автоматично.", "No fresh NOAA alerts right now, so we cannot say yes or no about a storm. We will update automatically.", "No hay avisos recientes de NOAA, así que no podemos decir sí o no sobre una tormenta. Se actualizará solo.", "Pas d’alertes NOAA récentes : impossible de dire oui ou non pour un orage. Mise à jour automatique."],
["Спостерігається: ", "Observed: ", "Observado: ", "Observé : "],
["G — геомагнітна буря; S — радіаційна буря; R — радіозатемнення. 0 — нижче порога шкали.", "G — geomagnetic storm; S — solar radiation storm; R — radio blackout. 0 — below the scale threshold.", "G — tormenta geomagnética; S — tormenta de radiación solar; R — apagón de radio. 0 — por debajo del umbral de la escala.", "G — tempête géomagnétique ; S — tempête de rayonnement solaire ; R — perturbation radio. 0 — en dessous du seuil de l’échelle."],
["доба UTC", "UTC day", "día UTC", "jour UTC"],
["Очікується: ", "Forecast: ", "Previsión: ", "Prévision : "],
["Імовірність: ", "Probability: ", "Probabilidad: ", "Probabilité : "],
["Прогноз попереджень недоступний.", "Alert forecast unavailable.", "Previsión de avisos no disponible.", "Prévision des alertes indisponible."],
["Оновлено NOAA: ", "NOAA updated: ", "Actualizado por NOAA: ", "Mise à jour NOAA : "],
["Очікувана буря не означає, що вона вже почалася. Ці показники не змінюють бал дня.", "A forecast storm does not mean it has already started. These indicators do not change the daily score.", "Una tormenta prevista no significa que ya haya comenzado. Estos indicadores no cambian la puntuación del día.", "Une tempête prévue ne signifie pas qu’elle a déjà commencé. Ces indicateurs ne modifient pas le score du jour."],
["Офіційні повідомлення NOAA", "Official NOAA notices", "Avisos oficiales de NOAA", "Communiqués officiels NOAA"],
['Зберегти прогноз у журнал','Save this forecast to the journal','Guardar el pronóstico en el diario','Enregistrer la prévision dans le journal'],
['Однаковість версій вхідних даних не підтверджена. Різниця з PDF сама по собі не доводить помилку формули.','Matching input versions have not been confirmed. A difference from the PDF alone does not prove a formula error.','No se ha confirmado que las versiones de los datos de entrada coincidan. Una diferencia con el PDF no demuestra por sí sola un error en la fórmula.','La correspondance des versions des données d’entrée n’est pas confirmée. Une différence avec le PDF ne prouve pas à elle seule une erreur de formule.'],
['Видалити локальні профілі, геолокацію, журнали, плани, налаштування та сесію входу SkyRhythm? Сторінка перезавантажиться. Публічний офлайн-кеш і серверний обліковий запис залишаться.','Delete local profiles, location, journals, plans, settings and the SkyRhythm sign-in session? The page will reload. The public offline cache and server account will remain.','¿Borrar perfiles locales, ubicación, diarios, planes, ajustes y la sesión de SkyRhythm? La página se recargará. Se conservarán la caché pública sin conexión y la cuenta del servidor.','Supprimer les profils locaux, la localisation, les journaux, les programmes, les réglages et la session SkyRhythm ? La page sera rechargée. Le cache public hors ligne et le compte serveur seront conservés.'],
['Час плану: ','Planned time: ','Hora prevista: ','Heure prévue : '],['Некоректний або неоднозначний київський час.','Invalid or ambiguous Kyiv time.','Hora de Kyiv no válida o ambigua.','Heure de Kyiv invalide ou ambiguë.'],['Спочатку збережіть план із часом.','First save a plan with a time.','Primero guarda un plan con una hora.','Enregistrez d’abord un programme avec une heure.'],
['Файл календаря створено. Відкрийте його, підтвердьте імпорт і перевірте нагадування у своєму календарі.','Calendar file created. Open it, confirm the import and check the reminder in your calendar.','Archivo de calendario creado. Ábrelo, confirma la importación y comprueba el recordatorio en tu calendario.','Fichier de calendrier créé. Ouvrez-le, confirmez l’importation et vérifiez le rappel dans votre calendrier.'],
['Експорт підготовлено локально; дані нікуди не надсилалися.','Export prepared locally; no data was sent anywhere.','Exportación preparada localmente; no se enviaron datos a ningún sitio.','Export préparé localement ; aucune donnée n’a été envoyée.'],
['Не вдалося експортувати локальні дані. Перевірте доступ до сховища й завантажень у браузері та повторіть.','Could not export local data. Check browser storage and download access, then try again.','No se pudieron exportar los datos locales. Comprueba el acceso al almacenamiento y a las descargas del navegador e inténtalo de nuevo.','Impossible d’exporter les données locales. Vérifiez l’accès au stockage et aux téléchargements du navigateur, puis réessayez.'],
['Локальні дані очищено на цьому пристрої.','Local data cleared on this device.','Datos locales borrados en este dispositivo.','Données locales effacées sur cet appareil.'],['Локальні дані очищено.','Local data cleared.','Datos locales borrados.','Données locales effacées.'],
['Не вдалося повністю очистити локальне сховище. Повторіть очищення через налаштування браузера.','Could not completely clear local storage. Clear it again through browser settings.','No se pudo borrar por completo el almacenamiento local. Repite el borrado desde los ajustes del navegador.','Impossible d’effacer complètement le stockage local. Recommencez depuis les réglages du navigateur.'],
['План збережено на цьому пристрої','Plan saved on this device','Plan guardado en este dispositivo','Programme enregistré sur cet appareil'],['Нагадування скасовано.','Reminder cancelled.','Recordatorio cancelado.','Rappel annulé.'],['Не вдалося зберегти локально','Could not save locally','No se pudo guardar localmente','Impossible d’enregistrer localement'],['Оберіть результат плану.','Select the plan’s outcome.','Selecciona el resultado del plan.','Sélectionnez le résultat du programme.'],['Фактичний результат збережено локально','Actual outcome saved locally','Resultado real guardado localmente','Résultat réel enregistré localement'],['Не вдалося зберегти результат','Could not save the outcome','No se pudo guardar el resultado','Impossible d’enregistrer le résultat'],
['Спочатку збережіть план і вкажіть коректний час.','First save the plan with a valid time.','Primero guarda el plan con una hora válida.','Enregistrez d’abord le programme avec une heure valide.'],
['Цей київський час не існує або повторюється під час переходу годинника. Оберіть інший час.','This Kyiv time is skipped or repeated during a clock change. Choose another time.','Esta hora de Kyiv no existe o se repite durante el cambio de hora. Elige otra hora.','Cette heure de Kyiv est inexistante ou répétée lors du changement d’heure. Choisissez une autre heure.'],
['Цей час уже минув. Оберіть майбутній час.','This time has passed. Choose a future time.','Esta hora ya pasó. Elige una hora futura.','Cette heure est passée. Choisissez une heure future.'],['Цей браузер не підтримує сповіщення.','This browser does not support notifications.','Este navegador no admite notificaciones.','Ce navigateur ne prend pas en charge les notifications.'],['Сповіщення не дозволені в налаштуваннях браузера.','Notifications are not allowed in browser settings.','Las notificaciones no están permitidas en los ajustes del navegador.','Les notifications ne sont pas autorisées dans les réglages du navigateur.'],['План або час змінився. Установіть нагадування повторно.','The plan or time has changed. Set the reminder again.','El plan o la hora han cambiado. Configura de nuevo el recordatorio.','Le programme ou l’heure a changé. Configurez à nouveau le rappel.'],['Сповіщення передано системі.','Notification passed to the system.','Notificación enviada al sistema.','Notification transmise au système.'],['Не вдалося показати сповіщення. Перевірте дозволи браузера.','Could not show the notification. Check browser permissions.','No se pudo mostrar la notificación. Comprueba los permisos del navegador.','Impossible d’afficher la notification. Vérifiez les autorisations du navigateur.'],['Нагадування на ','Reminder at ','Recordatorio a las ','Rappel à '],[' за Києвом. Залиште сторінку відкритою; після закриття або перезавантаження таймер не працює.',' Kyiv time. Keep the page open; the timer stops after closing or reloading.',' hora de Kyiv. Mantén la página abierta; el temporizador se detiene al cerrarla o recargarla.',' heure de Kyiv. Gardez la page ouverte ; le minuteur s’arrête à sa fermeture ou à son rechargement.'],['Не вдалося встановити нагадування. Перевірте дозволи й доступ до локального сховища.','Could not set the reminder. Check permissions and local storage access.','No se pudo configurar el recordatorio. Comprueba los permisos y el acceso al almacenamiento local.','Impossible de configurer le rappel. Vérifiez les autorisations et l’accès au stockage local.'],
['Карана · короткий ритм','Karana · short cycle','Karana · ciclo corto','Karana · cycle court'],
['Докладна Панчанга · таблиці, переходи та астрономічні деталі','Detailed Panchanga · tables, transitions and astronomical details','Panchanga detallado · tablas, transiciones y detalles astronómicos','Panchanga détaillé · tableaux, transitions et détails astronomiques'],
['Керування локальними даними','Manage local data','Gestionar datos locales','Gérer les données locales'],
['Звіт повторює канонічний Today і не створює іншого прогнозу.','The report repeats the canonical Today assessment and creates no additional forecast.','El informe repite la valoración canónica de Hoy y no crea otra previsión.','Le rapport reprend l’évaluation canonique d’Aujourd’hui et ne crée pas d’autre prévision.'],
['Завантаження календаря…','Loading calendar…','Cargando calendario…','Chargement du calendrier…'],['Плануй дію, перевірку або паузу','Plan an action, a review or a pause','Planifica una acción, una revisión o una pausa','Prévoyez une action, une vérification ou une pause'],['Завантажую canonical resolver…','Loading the assessment…','Cargando la valoración…','Chargement de l’évaluation…'],['Завантаження…','Loading…','Cargando…','Chargement…'],
['Перетвори висновок на план','Turn the assessment into a plan','Convierte la valoración en un plan','Transformez l’évaluation en programme'],
['Звіти використовують ті самі канонічні дані й не створюють паралельний прогноз.','Reports use the same canonical data and do not create a separate forecast.','Los informes usan los mismos datos canónicos y no crean una previsión paralela.','Les rapports utilisent les mêmes données canoniques et ne créent pas de prévision parallèle.'],
['ДОСТУПНО','AVAILABLE','DISPONIBLE','DISPONIBLE'],['Денний звіт','Daily report','Informe diario','Rapport quotidien'],['Висновок, причина, дія, обмеження та Kp-контекст.','Assessment, reasons, action, limits and Kp context.','Valoración, razones, acción, límites y contexto Kp.','Évaluation, raisons, action, limites et contexte Kp.'],['Друкувати / PDF','Print / PDF','Imprimir / PDF','Imprimer / PDF'],['ДОСЛІДЖЕННЯ','RESEARCH','INVESTIGACIÓN','RECHERCHE'],['30/90-денний план','30/90-day plan','Plan de 30/90 días','Programme sur 30/90 jours'],
['Гіпотеза календаря довшого горизонту; це не доступний продукт і не розширення 7-денних порад на дію.','A longer-range calendar hypothesis; not an available product or an extension of seven-day action guidance.','Hipótesis de calendario a más largo plazo; no es un producto disponible ni una ampliación de las orientaciones de acción a siete días.','Hypothèse de calendrier à plus long terme ; ce n’est ni un produit disponible ni une extension des indications d’action à sept jours.'],
['Що досліджується','What is being researched','Qué se investiga','Objet des recherches'],['ПОПЕРЕДНІЙ ПЕРЕГЛЯД','PREVIEW','VISTA PREVIA','APERÇU'],['Розрахунок за формулою джерела. Точність щодо подій не підтверджена.','Calculated using the source formula. Accuracy for events is unverified.','Cálculo con la fórmula de la fuente. La precisión sobre acontecimientos no está verificada.','Calcul selon la formule de la source. La précision concernant les événements n’est pas vérifiée.'],['Пояснення','Explanation','Explicación','Explication'],['Перегляньте складові оцінки та стан джерел.','Review the score components and source status.','Revisa los componentes de la puntuación y el estado de las fuentes.','Consultez les composantes du score et l’état des sources.'],['Межі оцінки','Assessment limits','Límites de la valoración','Limites de l’évaluation'],['Звіт повторює рішення «Сьогодні» і не створює іншого прогнозу.','The report repeats Today’s assessment and creates no additional forecast.','El informe repite la valoración de Hoy y no crea otra previsión.','Le rapport reprend l’évaluation d’Aujourd’hui et ne crée pas d’autre prévision.'],
['Як читати оцінку дня','How to read the daily score','Cómo interpretar la puntuación diaria','Comment lire le score quotidien'],['Одна оцінка за формулою джерела, її складові та календарні теми.','One score from the source formula, its components and calendar topics.','Una puntuación de la fórmula de la fuente, sus componentes y los temas del calendario.','Un score issu de la formule de la source, ses composantes et les thèmes du calendrier.'],['Що обчислюється','What is calculated','Qué se calcula','Ce qui est calculé'],
['Сума = (2 − прогноз добового максимуму Kp) + місячна складова Moon + складова затемнення Eclipse + сума ваг календарних позначок. Після округлення результат обмежується шкалою −3…+3.','Sum = (2 − forecast daily maximum Kp) + Moon component + Eclipse component + the sum of calendar-symbol weights. After rounding, the result is limited to −3…+3.','Suma = (2 − máximo diario previsto de Kp) + componente Moon + componente Eclipse + suma de los pesos de los símbolos del calendario. Tras redondear, el resultado se limita a −3…+3.','Somme = (2 − maximum quotidien prévu de Kp) + composante Moon + composante Eclipse + somme des pondérations des symboles du calendrier. Après arrondi, le résultat est limité à −3…+3.'],
['Це авторська формула. Її точність щодо реальних подій ще не підтверджена. Однаковий бал може відповідати різним наборам складових; дивіться причини та застереження джерела.','This is the author’s formula. Its accuracy for real events is not yet established. The same score can reflect different components; read the reasons and source cautions.','Esta es la fórmula del autor. Su precisión sobre acontecimientos reales aún no está demostrada. La misma puntuación puede corresponder a componentes distintos; consulta las razones y advertencias de la fuente.','Il s’agit de la formule de l’auteur. Sa précision concernant les événements réels n’est pas encore établie. Un même score peut correspondre à des composantes différentes ; consultez les raisons et les mises en garde de la source.'],
['Джерела й горизонт','Sources and forecast range','Fuentes y alcance de la previsión','Sources et horizon des prévisions'],
['Короткий прогноз використовує повні тригодинні слоти NOAA для доби Europe/Kyiv. Далекий орієнтир — 27-денний прогноз за добу UTC; це інший тип входу, позначений окремо.','The short forecast uses complete three-hour NOAA slots for the Europe/Kyiv day. The long-range reference is a 27-day outlook for UTC days; this different input type is labelled separately.','La previsión a corto plazo usa intervalos completos de tres horas de NOAA para el día Europe/Kyiv. La referencia a largo plazo es una previsión de 27 días según días UTC; este tipo de entrada diferente se indica por separado.','Les prévisions à court terme utilisent des intervalles NOAA complets de trois heures pour le jour Europe/Kyiv. Le repère à long terme est une prévision à 27 jours selon les jours UTC ; ce type de donnée distinct est signalé séparément.'],
['Календар і дослідження','Calendar and research','Calendario e investigación','Calendrier et recherche'],
['Панчанга й планетарний контекст показані окремо. Pᵢ і Dᵢ зі старої формули Hero G не входять у показану оцінку. Експертний PDF — джерело для порівняння; Engine — модель відтворення експерта; Tanita — дослідницький канал. Їхній збіг не доводить точності щодо подій.','Panchanga and planetary context are displayed separately. Pᵢ and Dᵢ from the old Hero G formula are not part of the displayed score. The expert PDF is a comparison source; Engine reproduces the expert; Tanita is a research channel. Their agreement does not demonstrate accuracy for events.','Panchanga y el contexto planetario se muestran por separado. Pᵢ y Dᵢ de la antigua fórmula Hero G no forman parte de la puntuación mostrada. El PDF experto es una fuente de comparación; Engine reproduce al experto; Tanita es un canal de investigación. Su coincidencia no demuestra precisión sobre acontecimientos.','Le Panchanga et le contexte planétaire sont présentés séparément. Pᵢ et Dᵢ de l’ancienne formule Hero G ne font pas partie du score affiché. Le PDF expert sert de comparaison ; Engine reproduit l’expert ; Tanita est un canal de recherche. Leur concordance ne démontre pas la précision concernant les événements.'],
['Як перевіряється прогноз','How forecasts are evaluated','Cómo se evalúa la previsión','Comment les prévisions sont évaluées'],
['Прогноз формули фіксується до початку наступної доби за окремим протоколом v2. Після дня потрібні незалежні оцінки A–D: стан або настрій, продуктивність, фізичний стан і зовнішні події. Особистий план і локальний щоденник не замінюють цю перевірку.','The formula forecast is recorded before the next day starts under a separate v2 protocol. After the day, independent A–D ratings are needed: state or mood, productivity, physical condition and external events. A personal plan and local journal do not replace this evaluation.','La previsión de la fórmula se registra antes del inicio del día siguiente mediante un protocolo v2 separado. Después del día se necesitan valoraciones independientes A–D: estado o ánimo, productividad, condición física y acontecimientos externos. El plan personal y el diario local no sustituyen esta evaluación.','Les prévisions de la formule sont enregistrées avant le début du jour suivant selon un protocole v2 distinct. Après la journée, des évaluations indépendantes A–D sont nécessaires : état ou humeur, productivité, condition physique et événements externes. Le programme personnel et le journal local ne remplacent pas cette évaluation.'],
['СПІЛЬНЕ ПЛАНУВАННЯ','SHARED PLANNING','PLANIFICACIÓN COMPARTIDA','PLANIFICATION COMMUNE'],['Базовий контур дня для двох','A shared daily overview for two','Resumen diario compartido para dos','Aperçu quotidien commun pour deux'],
['Показує спільний канонічний контур дня. Персональний перетин за датою, часом чи містом ще не обчислюється.','Shows the shared canonical daily overview. Personal overlap based on date, time or city is not calculated yet.','Muestra el resumen diario canónico compartido. Aún no se calcula una coincidencia personal según fecha, hora o ciudad.','Présente l’aperçu quotidien canonique commun. Le croisement personnel selon la date, l’heure ou la ville n’est pas encore calculé.'],
['З ким плануєте','Who are you planning with?','¿Con quién planificas?','Avec qui planifiez-vous ?'],
['Потрібне лише ім’я для локального підпису. Дані народження не збираються, бо валідованої моделі персонального перетину немає.','Only a name is needed for a local label. Birth data is not collected because there is no validated personal-overlap model.','Solo se necesita un nombre como etiqueta local. No se recogen datos de nacimiento porque no existe un modelo validado de coincidencia personal.','Seul un nom est nécessaire pour un libellé local. Les données de naissance ne sont pas collectées, car aucun modèle de croisement personnel n’est validé.'],
['Ім’я другої людини','Other person’s name','Nombre de la otra persona','Nom de l’autre personne'],['Використовується лише у назві локального плану.','Used only in the local plan’s title.','Se usa solo en el título del plan local.','Utilisé uniquement dans le titre du programme local.'],['Показати базовий контур дня','Show the daily overview','Mostrar el resumen del día','Afficher l’aperçu du jour'],['Перейти до локального профілю','Open local profile','Abrir el perfil local','Ouvrir le profil local'],['БАЗОВИЙ КОНТУР','DAILY OVERVIEW','RESUMEN DIARIO','APERÇU QUOTIDIEN'],['Вкажіть ім’я другої людини','Enter the other person’s name','Introduce el nombre de la otra persona','Saisissez le nom de l’autre personne'],
['Дата, час і місто не потрібні: персональний перетин ще не обчислюється.','Date, time and city are not needed: personal overlap is not calculated yet.','No se necesitan fecha, hora ni ciudad: aún no se calcula una coincidencia personal.','La date, l’heure et la ville ne sont pas nécessaires : le croisement personnel n’est pas encore calculé.'],['Ви','You','Tú','Vous'],
['Джерело: канонічне рішення «Сьогодні». Це не персональний перетин і не оцінка сумісності; дата, час та місто не використовуються.','Source: the canonical Today assessment. This is not personal overlap or compatibility scoring; date, time and city are not used.','Fuente: valoración canónica de Hoy. No es una coincidencia personal ni una puntuación de compatibilidad; no se usan fecha, hora ni ciudad.','Source : l’évaluation canonique d’Aujourd’hui. Ce n’est ni un croisement personnel ni un score de compatibilité ; la date, l’heure et la ville ne sont pas utilisées.']
]);
NRLocale.register([
['ЛОКАЛЬНИЙ ПРОФІЛЬ','LOCAL PROFILE','PERFIL LOCAL','PROFIL LOCAL'],['ЛОКАЛЬНІ ДАНІ','LOCAL DATA','DATOS LOCALES','DONNÉES LOCALES'],['Локальний профіль','Local profile','Perfil local','Profil local'],['Дані на цьому пристрої','Data on this device','Datos en este dispositivo','Données sur cet appareil'],
['Поля нижче не змінюють канонічне рішення дня. Біля кожного поля прямо вказано його поточне використання.','The fields below do not change the day’s assessment. Each field explains how it is currently used.','Los campos siguientes no cambian la valoración del día. Cada campo explica su uso actual.','Les champs ci-dessous ne modifient pas l’évaluation du jour. Chaque champ précise son utilisation actuelle.'],
['Мої локальні дані','My local data','Mis datos locales','Mes données locales'],
['Зберігаються лише у браузері. Персональна модель ще не валідована. Дату народження можна додати в «Сьогодні» (транзити від натального Місяця); вона зберігається лише тут і на бал не впливає.','Stored only in this browser. The personal model is not yet validated. You can add a birth date on Today (transits to the natal Moon); it stays on this device and does not affect the score.','Se guardan solo en este navegador. El modelo personal aún no está validado. Puedes añadir la fecha de nacimiento en Hoy (tránsitos a la Luna natal); se queda en este dispositivo y no afecta a la puntuación.','Stockées uniquement dans ce navigateur. Le modèle personnel n’est pas encore validé. Vous pouvez ajouter une date de naissance dans Aujourd’hui (transits sur la Lune natale) ; elle reste sur cet appareil et n’affecte pas le score.'],
['Ім’я','Name','Nombre','Nom'],['Місто','City','Ciudad','Ville'],['Показується у локальному профілі та спільному плануванні.','Shown in the local profile and shared planning.','Se muestra en el perfil local y la planificación compartida.','Affiché dans le profil local et la planification commune.'],
['Збережене для майбутнього локального контексту; зараз не змінює рішення дня.','Saved for future local context; it does not currently change the day’s assessment.','Guardada para un futuro contexto local; actualmente no cambia la valoración del día.','Enregistrée pour un futur contexte local ; elle ne modifie actuellement pas l’évaluation du jour.'],
['Режим пояснення','Explanation mode','Modo de explicación','Mode d’explication'],['Локальна перевага відображення; не змінює рішення.','Local display preference; does not change the assessment.','Preferencia local de visualización; no cambia la valoración.','Préférence locale d’affichage ; ne modifie pas l’évaluation.'],['Простий','Simple','Sencillo','Simple'],['Докладний','Detailed','Detallado','Détaillé'],['Зберегти локально','Save locally','Guardar localmente','Enregistrer localement'],['Експортувати мої дані','Export my data','Exportar mis datos','Exporter mes données'],['Очистити локальні дані','Clear local data','Borrar datos locales','Effacer les données locales'],
['Очищення видаляє локальні профілі, геолокацію, журнали, плани, налаштування та локальну сесію входу SkyRhythm й перезавантажує сторінку. Публічний офлайн-кеш сайту та дані інших застосунків залишаються. Серверний обліковий запис не видаляється. Експорт охоплює локальні записи, крім токена входу.','Clearing removes local profiles, location, journals, plans, settings and the local SkyRhythm sign-in session, then reloads the page. The public offline site cache and other apps’ data remain. The server account is not deleted. Export includes local records except the sign-in token.','El borrado elimina perfiles locales, ubicación, diarios, planes, ajustes y la sesión local de SkyRhythm, y recarga la página. Se conservan la caché pública sin conexión y los datos de otras aplicaciones. No se elimina la cuenta del servidor. La exportación incluye los registros locales, excepto el token de acceso.','L’effacement supprime les profils locaux, la localisation, les journaux, les programmes, les réglages et la session locale SkyRhythm, puis recharge la page. Le cache public hors ligne du site et les données des autres applications sont conservés. Le compte serveur n’est pas supprimé. L’export inclut les données locales, sauf le jeton de connexion.'],
['ЛОКАЛЬНИЙ СТАН','LOCAL STATUS','ESTADO LOCAL','ÉTAT LOCAL'],['полів збережено','fields saved','campos guardados','champs enregistrés'],['Профіль ще не збережено','Profile not saved yet','Perfil aún no guardado','Profil pas encore enregistré'],
['Ім’я використовується для локального підпису. Місто не змінює оцінку; старі дані народження збережені лише у локальній копії. Ці поля не змінюють рішення у «Сьогодні», «Прогнозі» або «Календарі».','Your name is used as a local label. The city does not change the score; old birth data remains only in your local copy. These fields do not change the assessment in Today, Forecast or Calendar.','Tu nombre se usa como etiqueta local. La ciudad no cambia la puntuación; los antiguos datos de nacimiento solo permanecen en tu copia local. Estos campos no cambian la valoración en Hoy, Previsión o Calendario.','Votre nom sert de libellé local. La ville ne modifie pas le score ; les anciennes données de naissance restent uniquement dans votre copie locale. Ces champs ne modifient pas l’évaluation dans Aujourd’hui, Prévisions ou Calendrier.'],
['Зберігання: лише цей пристрій · серверне надсилання: ні · валідована персональна модель: ні.','Storage: this device only · sent to server: no · validated personal model: no.','Almacenamiento: solo este dispositivo · envío al servidor: no · modelo personal validado: no.','Stockage : cet appareil uniquement · envoi au serveur : non · modèle personnel validé : non.'],
['Дані збережено лише на цьому пристрої','Data saved only on this device','Datos guardados solo en este dispositivo','Données enregistrées uniquement sur cet appareil'],['Не вдалося зберегти дані на пристрої','Could not save data on the device','No se pudieron guardar los datos en el dispositivo','Impossible d’enregistrer les données sur l’appareil'],
['ЩЕ','MORE','MÁS','PLUS'],['Усі інструменти','All tools','Todas las herramientas','Tous les outils'],['Категорії, спільний ритм, форми планування, звіти та окремий технічний dashboard.','Categories, shared planning, forms, reports and a separate technical dashboard.','Categorías, planificación compartida, formularios, informes y un panel técnico separado.','Catégories, planification commune, formulaires, rapports et tableau de bord technique distinct.'],
['КОНЦЕПЦІЯ','ABOUT','ACERCA DE','À PROPOS'],['Сонце, зорі та духовний ритм','Sun, stars and traditional context','Sol, estrellas y contexto tradicional','Soleil, étoiles et contexte traditionnel'],['Сенс системи й чесна межа між прогнозами та пояснювальними впливами.','How the system works and the distinction between forecasts and explanatory context.','Cómo funciona el sistema y la diferencia entre previsiones y contexto explicativo.','Le fonctionnement du système et la distinction entre prévisions et contexte explicatif.'],
['Приватні поля й пояснення їх фактичного використання; рішення дня не змінюється.','Private fields and explanations of their actual use; the day’s assessment is unchanged.','Campos privados y explicación de su uso real; la valoración del día no cambia.','Champs privés et explication de leur utilisation réelle ; l’évaluation du jour reste inchangée.'],
['КАЛЕНДАРНИЙ ШАР','CALENDAR CONTEXT','CONTEXTO DEL CALENDARIO','CONTEXTE DU CALENDRIER'],['П’ять компонентів часу простими словами; технічні деталі окремо.','Five components of time in plain language; technical details shown separately.','Cinco componentes del tiempo explicados con sencillez; los detalles técnicos se muestran aparte.','Cinq composantes du temps expliquées simplement ; les détails techniques sont présentés à part.'],
['КЛЮЧ ДНЯ','DAILY FOCUS','ENFOQUE DEL DÍA','OBJECTIF DU JOUR'],['Категорії дня','Daily categories','Categorías del día','Catégories du jour'],['Календарні позначки за сферою та власні нотатки; окремих балів немає.','Calendar symbols by area and your own notes; no separate scores.','Símbolos del calendario por ámbito y tus notas; sin puntuaciones separadas.','Symboles du calendrier par domaine et notes personnelles ; aucun score distinct.'],
['ПЛАНУВАННЯ','PLANNING','PLANIFICACIÓN','PLANIFICATION'],['Спільне планування','Shared planning','Planificación compartida','Planification commune'],['Базовий контур дня для двох; персональний перетин ще не обчислюється.','A shared daily overview for two people; personal overlap is not calculated yet.','Resumen diario compartido para dos personas; aún no se calcula una coincidencia personal.','Un aperçu quotidien commun pour deux personnes ; le croisement personnel n’est pas encore calculé.'],
['ЗВІТИ','REPORTS','INFORMES','RAPPORTS'],['Звіти й планування','Reports and planning','Informes y planificación','Rapports et planification'],['Денний звіт, календар і довші горизонти.','Daily report, calendar and longer ranges.','Informe diario, calendario y horizontes más largos.','Rapport quotidien, calendrier et horizons plus lointains.'],['ПЛАН','PLAN','PLAN','PROGRAMME'],['Мій план дня','My daily plan','Mi plan del día','Mon programme du jour'],['Запишіть пріоритет, за бажанням — контакт і час.','Record a priority, with an optional contact and time.','Anota una prioridad y, si quieres, un contacto y una hora.','Notez une priorité, avec un contact et une heure facultatifs.'],
['Обери одну сферу сьогодні','Choose one focus for today','Elige un ámbito para hoy','Choisissez un domaine pour aujourd’hui'],['Категорія показує відповідні календарні позначки та місце для власного плану. Окремих прогнозів успіху для цих сфер немає.','The category shows relevant calendar symbols and space for your plan. There are no separate success forecasts for these areas.','La categoría muestra símbolos relevantes del calendario y espacio para tu plan. No hay previsiones de éxito separadas para estos ámbitos.','La catégorie présente les symboles pertinents du calendrier et un espace pour votre programme. Il n’existe pas de prévisions de réussite distinctes pour ces domaines.'],
['Техніка, навантаження та відновлення','Technique, workload and recovery','Técnica, carga y recuperación','Technique, charge et récupération'],['Обрати сьогодні','Choose for today','Elegir para hoy','Choisir pour aujourd’hui'],['Орієнтир для самоспостереження, не медична порада','A prompt for self-observation, not medical advice','Orientación para la autoobservación, no consejo médico','Repère pour l’auto-observation, pas un conseil médical'],['Бізнес і кар’єра','Business and career','Negocios y carrera','Travail et carrière'],['Рішення, переговори та робочі вікна','Decisions, discussions and work periods','Decisiones, conversaciones y períodos de trabajo','Décisions, discussions et périodes de travail'],['Любов і відносини','Love and relationships','Amor y relaciones','Amour et relations'],['Спілкування та спільні плани','Communication and shared plans','Comunicación y planes compartidos','Communication et projets communs'],['Гроші та ресурси','Money and resources','Dinero y recursos','Argent et ressources'],['Планування й перегляд, не фінансова порада','Planning and review, not financial advice','Planificación y revisión, no asesoramiento financiero','Planification et révision, pas un conseil financier']
]);
NRLocale.register([
['пʼятниця','Friday','viernes','vendredi'],
['ПЛАН І ЩОДЕННИК','PLANNER AND JOURNAL','PLANIFICADOR Y DIARIO','AGENDA ET JOURNAL'],
['Мій план і підсумок','My plan and reflection','Mi plan y balance','Mon programme et mon bilan'],
['Один пріоритет, один контакт і часовий намір. Запис зберігається лише на цьому пристрої та не створює нового прогнозу.','One priority, one contact and a planned time. The entry stays on this device and does not create a new forecast.','Una prioridad, un contacto y una hora prevista. El registro permanece en este dispositivo y no crea una nueva previsión.','Une priorité, un contact et un horaire prévu. La note reste sur cet appareil et ne crée pas de nouvelle prévision.'],
['Записати підсумок дня','Record the daily reflection','Registrar el balance del día','Noter le bilan du jour'],
['Оцінка календарної моделі','Calendar model score','Puntuación del modelo de calendario','Score du modèle calendaire'],
['КАЛЕНДАРНИЙ КОНТЕКСТ','CALENDAR CONTEXT','CONTEXTO DEL CALENDARIO','CONTEXTE DU CALENDRIER'],
['Оцінка не гарантує результату справ і не визначає найкращий час.','The score does not guarantee outcomes or identify the best time.','La puntuación no garantiza resultados ni determina el mejor momento.','Le score ne garantit aucun résultat et ne détermine pas le meilleur moment.'],
['План допомагає діяти в межах канонічного висновку дня і не створює нового прогнозу.','The plan helps you work within the day’s model assessment and does not create a new forecast.','El plan ayuda a actuar dentro de la valoración del modelo para el día y no crea una nueva previsión.','Le programme accompagne vos actions dans le cadre de l’évaluation du jour et ne crée pas de nouvelle prévision.'],
['Головний пріоритет','Main priority','Prioridad principal','Priorité principale'],
['Додаткові поля плану','Optional plan details','Detalles opcionales del plan','Détails facultatifs du programme'],
['Важливий контакт','Important contact','Contacto importante','Contact important'],
['Час за Києвом (Europe/Kyiv)','Kyiv time (Europe/Kyiv)','Hora de Kyiv (Europe/Kyiv)','Heure de Kyiv (Europe/Kyiv)'],
['Сфера','Area','Ámbito','Domaine'],['Загальне','General','General','Général'],['Бізнес','Business','Negocios','Activité professionnelle'],['Здоров’я та енергія','Health and energy','Salud y energía','Santé et énergie'],['Спорт','Sport','Deporte','Sport'],['Гроші','Money','Dinero','Argent'],['Нотатка','Note','Nota','Note'],
['Зберегти план','Save plan','Guardar plan','Enregistrer le programme'],
['Таймер відкритої сторінки','Timer while the page is open','Temporizador con la página abierta','Minuteur tant que la page est ouverte'],
['Додати в календар (.ics)','Add to calendar (.ics)','Añadir al calendario (.ics)','Ajouter au calendrier (.ics)'],
['Таймер працює лише поки сторінка відкрита й активна. Для нагадування після закриття імпортуйте файл .ics у свій календар і перевірте його дозвіл на сповіщення.','The timer only works while the page is open and active. For a reminder after closing it, import the .ics file into your calendar and check its notification permission.','El temporizador solo funciona mientras la página está abierta y activa. Para recibir un recordatorio después de cerrarla, importa el archivo .ics a tu calendario y comprueba su permiso de notificaciones.','Le minuteur fonctionne uniquement lorsque la page est ouverte et active. Pour un rappel après sa fermeture, importez le fichier .ics dans votre calendrier et vérifiez son autorisation de notification.'],
['ПЛАН НА СЬОГОДНІ','TODAY’S PLAN','PLAN DE HOY','PROGRAMME DU JOUR'],
['План ще не збережено','No plan saved yet','Aún no se ha guardado un plan','Aucun programme enregistré'],
['Достатньо одного пріоритету. Час та інші поля — за бажанням.','One priority is enough. Time and other fields are optional.','Una prioridad es suficiente. La hora y los demás campos son opcionales.','Une priorité suffit. L’heure et les autres champs sont facultatifs.'],
['ФАКТ ПІСЛЯ ДІЇ','OUTCOME AFTER ACTION','RESULTADO TRAS LA ACCIÓN','RÉSULTAT APRÈS L’ACTION'],
['Чим завершився план?','How did the plan turn out?','¿Cómo terminó el plan?','Comment s’est déroulé votre programme ?'],
['Це ваш локальний щоденник. Відповідь не змінює модель і не вважається незалежною валідацією.','This is your local journal. Your response does not change the model and is not independent validation.','Este es tu diario local. Tu respuesta no cambia el modelo ni constituye una validación independiente.','C’est votre journal local. Votre réponse ne modifie pas le modèle et ne constitue pas une validation indépendante.'],
['Результат','Outcome','Resultado','Résultat'],['Оберіть','Select','Selecciona','Sélectionnez'],['Не виконано','Not completed','No realizado','Non réalisé'],['Виконано','Completed','Realizado','Réalisé'],['Частково','Partly completed','Parcialmente realizado','Partiellement réalisé'],
['Короткий коментар','Brief comment','Comentario breve','Bref commentaire'],['Зберегти результат','Save outcome','Guardar resultado','Enregistrer le résultat'],
['ІСТОРІЯ · ЛИШЕ ЦЕЙ ПРИСТРІЙ','HISTORY · THIS DEVICE ONLY','HISTORIAL · SOLO ESTE DISPOSITIVO','HISTORIQUE · CET APPAREIL UNIQUEMENT'],['ІСТОРІЯ','HISTORY','HISTORIAL','HISTORIQUE'],['Останні результати','Recent outcomes','Resultados recientes','Résultats récents'],['Записів ще немає.','No entries yet.','Todavía no hay registros.','Aucune entrée pour le moment.'],
['ЗБЕРЕЖЕНО ЛОКАЛЬНО','SAVED LOCALLY','GUARDADO LOCALMENTE','ENREGISTRÉ LOCALEMENT'],['Без назви','Untitled','Sin título','Sans titre'],['Час за Києвом: ','Kyiv time: ','Hora de Kyiv: ','Heure de Kyiv : '],['Контакт: ','Contact: ','Contacto: ','Contact : '],['Дата плану: ','Plan date: ','Fecha del plan: ','Date du programme : '],['це запис користувача, не прогноз.','this is your entry, not a forecast.','es un registro tuyo, no una previsión.','il s’agit de votre note, pas d’une prévision.'],
['Самозвіт користувача; не ground truth і не доказ точності прогнозу.','User self-report; not ground truth or evidence of forecast accuracy.','Autoinforme del usuario; no es una referencia objetiva ni prueba de la precisión de la previsión.','Déclaration de l’utilisateur ; ni vérité de référence ni preuve de précision des prévisions.'],
['Панчанга на сьогодні','Today’s Panchanga','Panchanga de hoy','Panchanga du jour'],
['Календар дня від півночі до півночі за місцевим часом: що діє зараз, коли й на що змінюється.','Midnight-to-midnight local calendar: current components and when they change.','Calendario local de medianoche a medianoche: componentes actuales y cuándo cambian.','Calendrier local de minuit à minuit : composantes actuelles et moments de leurs changements.'],
['ПАНЧАНГА ДНЯ','DAILY PANCHANGA','PANCHANGA DEL DÍA','PANCHANGA DU JOUR'],['Що діє зараз','Current components','Componentes actuales','Composantes actuelles'],['НАСТУПНА ЗМІНА О ','NEXT CHANGE AT ','PRÓXIMO CAMBIO A LAS ','PROCHAIN CHANGEMENT À '],['ПЕРЕХОДИ ДНЯ ЗАВЕРШЕНО','TODAY’S TRANSITIONS COMPLETE','TRANSICIONES DEL DÍA COMPLETADAS','TRANSITIONS DU JOUR TERMINÉES'],
['місячний ритм','lunar rhythm','ritmo lunar','rythme lunaire'],['управитель дня','traditional ruler of the day','regente tradicional del día','maître traditionnel du jour'],['без наступної зміни сьогодні','no further change today','sin más cambios hoy','aucun autre changement aujourd’hui'],['характер дії','traditional character of action','carácter tradicional de la acción','caractère traditionnel de l’action'],['фон взаємодії','traditional interaction context','contexto tradicional de interacción','contexte traditionnel d’interaction'],['короткий практичний ритм','short practical rhythm','ritmo práctico breve','rythme pratique court'],
['до ','until ','hasta las ','jusqu’à '],[', далі ', ', then ', ', después ', ', puis '],['Середа · Меркурій','Wednesday · Mercury','Miércoles · Mercurio','Mercredi · Mercure'],['Неділя · Сонце','Sunday · Sun','Domingo · Sol','Dimanche · Soleil'],['Понеділок · Місяць','Monday · Moon','Lunes · Luna','Lundi · Lune'],['Вівторок · Марс','Tuesday · Mars','Martes · Marte','Mardi · Mars'],['Четвер · Юпітер','Thursday · Jupiter','Jueves · Júpiter','Jeudi · Jupiter'],['П’ятниця · Венера','Friday · Venus','Viernes · Venus','Vendredi · Vénus'],['Субота · Сатурн','Saturday · Saturn','Sábado · Saturno','Samedi · Saturne'],
['ШКАЛА ДОБИ','DAILY TIMELINE','CRONOLOGÍA DEL DÍA','CHRONOLOGIE DU JOUR'],['Усі переходи сьогодні','All transitions today','Todas las transiciones de hoy','Toutes les transitions du jour'],['починається','starts','comienza','commence'],
['Переходів до завершення календарної доби немає.','No transitions before the calendar day ends.','No hay transiciones antes de que termine el día del calendario.','Aucune transition avant la fin du jour calendaire.'],
['ЯК ЧИТАТИ','HOW TO READ','CÓMO INTERPRETAR','COMMENT LIRE'],['П’ять частин одного календарного шару','Five parts of one calendar','Cinco partes de un mismo calendario','Cinq parties d’un même calendrier'],
['Фаза календарного циклу та його загальний темп.','Stage of the calendar cycle and its traditional pace.','Etapa del ciclo del calendario y su ritmo tradicional.','Étape du cycle calendaire et son rythme traditionnel.'],
['Традиційний управитель сонячної доби.','Traditional ruler of the solar day.','Regente tradicional del día solar.','Maître traditionnel du jour solaire.'],
['Ділянка сидеричного шляху Місяця.','A section of the Moon’s sidereal path.','Un tramo del recorrido sidéreo de la Luna.','Une portion du parcours sidéral de la Lune.'],
['Комбінація довгот Сонця й Місяця.','Combination of the Sun’s and Moon’s longitudes.','Combinación de las longitudes del Sol y la Luna.','Combinaison des longitudes du Soleil et de la Lune.'],
['Половина Tithi, тому протягом дня змінюється частіше.','Half a tithi, so it changes more often during the day.','Medio tithi, por lo que cambia con mayor frecuencia durante el día.','Un demi-tithi, qui change donc plus souvent au cours de la journée.'],
['Це традиційний календарний контекст для осмисленого планування, а не гарантія події чи причинно доведений прогноз. Ця панель показує календарний контекст. Композит Pᵢ зі старої Hero G не входить у показану оцінку source_formula; додаткового бала з цієї панелі немає.','Traditional calendar context for thoughtful planning, not a guarantee or a causally established forecast. The old Hero G composite Pᵢ is not part of the displayed source_formula score; this panel adds no points.','Contexto del calendario tradicional para planificar con atención, no una garantía ni una previsión causal demostrada. El compuesto Pᵢ de la antigua Hero G no forma parte de la puntuación source_formula mostrada; este panel no añade puntos.','Contexte du calendrier traditionnel pour une planification réfléchie, sans garantie ni prévision causale établie. Le composite Pᵢ de l’ancienne Hero G ne fait pas partie du score source_formula affiché ; ce panneau n’ajoute aucun point.'],
['Повернутися до рішення дня','Back to the day’s assessment','Volver a la valoración del día','Revenir à l’évaluation du jour'],['Відкрити астрономічні деталі','Open astronomical details','Abrir los detalles astronómicos','Ouvrir les détails astronomiques'],['Переходи Панчанги недоступні: ','Panchanga transitions unavailable: ','Transiciones de Panchanga no disponibles: ','Transitions du Panchanga indisponibles : '],['немає дня ','missing date ','falta la fecha ','date manquante ']
]);
NRLocale.register([
['У джерелі є застереження щодо нових починань.','The source cautions against new beginnings.','La fuente advierte sobre nuevos comienzos.','La source met en garde contre les nouveaux départs.'],
['У джерелі є позначка повторної роботи — перевірте деталі плану.','The source indicates repeated work; check the details of your plan.','La fuente señala trabajo repetido; revisa los detalles de tu plan.','La source signale un travail à refaire ; vérifiez les détails de votre programme.'],
['Навчання й нові знання','Learning and new knowledge','Aprendizaje y nuevos conocimientos','Apprentissage et nouvelles connaissances'],
['Планування й постановка цілей','Planning and setting goals','Planificación y definición de objetivos','Planification et définition d’objectifs'],
['Стрижка й особистий догляд','Haircuts and personal care','Cortes de pelo y cuidado personal','Coiffure et soins personnels'],
['Новий одяг','New clothing','Ropa nueva','Vêtements neufs'],
['Реклама й комунікація','Advertising and communication','Publicidad y comunicación','Publicité et communication'],
['Окремих календарних позначок немає.','No specific calendar symbols.','No hay símbolos específicos del calendario.','Aucun symbole particulier du calendrier.'],
['Поки немає календарних входів для цієї дати.','No calendar inputs available for this date yet.','Aún no hay datos del calendario para esta fecha.','Aucune donnée du calendrier n’est encore disponible pour cette date.'],
['сприятливий для подорожей','favourable for travel in the source','favorable para viajar según la fuente','favorable aux voyages selon la source'],
['сприятливий для стрижки','favourable for haircuts in the source','favorable para cortarse el pelo según la fuente','favorable à une coupe de cheveux selon la source'],
['SKYRHYTHM','SKYRHYTHM','SKYRHYTHM','SKYRHYTHM'],
['Огляд дня','Day overview','Resumen del día','Aperçu du jour'],
['Прогноз і горизонт','Forecast and range','Previsión y alcance','Prévisions et horizon'],
['Календар за темами','Calendar by topic','Calendario por temas','Calendrier par thème'],
['Дата оцінки','Assessment date','Fecha de la valoración','Date de l’évaluation'],
['Дата','Date','Fecha','Date'],
['Дані актуальні','Data up to date','Datos actualizados','Données à jour'],
['Офлайн · збережені дані','Offline · saved data','Sin conexión · datos guardados','Hors ligne · données enregistrées'],
['Дані застаріли','Data out of date','Datos desactualizados','Données périmées'],
['Недостатньо даних','Not enough data','Datos insuficientes','Données insuffisantes'],
['Час джерела не підтверджено','Source time unverified','Hora de la fuente sin verificar','Horodatage de la source non vérifié'],
['сьогодні за Києвом','today in Kyiv','hoy en Kyiv','aujourd’hui à Kyiv'],
['Позитивна оцінка','Positive assessment','Valoración positiva','Évaluation positive'],
['Негативна оцінка','Negative assessment','Valoración negativa','Évaluation négative'],
['Нейтральна оцінка','Neutral assessment','Valoración neutra','Évaluation neutre'],
['Актуальну оцінку не показуємо','No current assessment available','No hay una valoración actual disponible','Aucune évaluation actuelle disponible'],
['Оцінка моделі','Model score','Puntuación del modelo','Score du modèle'],
['Шкала моделі: −3…+3 · від негативної до позитивної оцінки; 0 — нейтральна.','Model scale: −3 to +3 · negative to positive; 0 is neutral.','Escala del modelo: de −3 a +3 · de negativa a positiva; 0 es neutro.','Échelle du modèle : de −3 à +3 · du négatif au positif ; 0 est neutre.'],
['Космічна погода','Space weather','Clima espacial','Météo spatiale'],
['Поточний Kp недоступний — запасне число не показуємо.','Current Kp unavailable; no substitute value is shown.','Kp actual no disponible; no se muestra un valor sustitutivo.','Kp actuel indisponible ; aucune valeur de remplacement n’est affichée.'],
['Фізичні дані окремо від календарних тем.','Physical data shown separately from calendar topics.','Datos físicos separados de los temas del calendario.','Les données physiques sont distinctes des thèmes du calendrier.'],
['Зараз Kp ','Current Kp ','Kp actual ','Kp actuel '],
['Прогноз добового максимуму Kp ','Forecast daily maximum Kp ','Máximo diario de Kp previsto ','Maximum quotidien prévu de Kp '],
['Немає актуального фізичного прогнозу для цієї дати.','No current physical forecast for this date.','No hay una previsión física actual para esta fecha.','Aucune prévision physique actuelle pour cette date.'],
['часовий пояс не вказано','time zone unspecified','zona horaria no indicada','fuseau horaire non précisé'],
['01 · СПЛАНУВАТИ','01 · PLAN','01 · PLANIFICA','01 · PLANIFIER'],
['02 · ПОРІВНЯТИ','02 · COMPARE','02 · COMPARA','02 · COMPARER'],
['03 · ПІДСУМУВАТИ','03 · REFLECT','03 · REVISA','03 · FAIRE LE BILAN'],
['ПОРІВНЯТИ','COMPARE','COMPARA','COMPARER'],
['ДЛЯ ТЕБЕ · ДОСЛІДНА','FOR YOU · RESEARCH','PARA TI · INVESTIGACIÓN','POUR VOUS · RECHERCHE'],
['Особиста лінія дня','Personal day line','Línea personal del día','Ligne personnelle du jour'],
['Місяць, тітхі й твоя Тара кожні 3 години. Дата народження лишається лише в цьому браузері.','Moon, tithi and your Tara every 3 hours. Your birth date stays in this browser only.','Luna, tithi y tu Tara cada 3 horas. Tu fecha de nacimiento se queda solo en este navegador.','Lune, tithi et votre Tara toutes les 3 heures. Votre date de naissance reste uniquement dans ce navigateur.'],
['ПІДСУМУВАТИ','REFLECT','REVISA','FAIRE LE BILAN'],
['Мій план','My plan','Mi plan','Mon programme'],
['Обрати дату','Choose a date','Elegir fecha','Choisir une date'],
['Записати результат','Record the outcome','Registrar el resultado','Noter le résultat'],
['Чому така оцінка','Why this score','Por qué esta puntuación','Pourquoi ce score'],
['Найбільші внески','Largest contributions','Mayores contribuciones','Principales contributions'],
['; повна сума до округлення й обмеження: ','; total before rounding and limiting: ','; suma antes del redondeo y los límites: ',' ; somme avant arrondi et limitation : '],
['Внески збереженого розрахунку; актуальний підсумок недоступний.','Saved calculation contributions; current total unavailable.','Contribuciones del cálculo guardado; total actual no disponible.','Contributions du calcul enregistré ; total actuel indisponible.'],
['Складові для цієї дати недоступні.','Components unavailable for this date.','Componentes no disponibles para esta fecha.','Composantes indisponibles pour cette date.'],
['Значення позначок і джерело','Calendar symbols and source','Símbolos del calendario y fuente','Symboles du calendrier et source'],
['Геомагнітна складова (2 − Kp максимум)','Geomagnetic component (2 − maximum Kp)','Componente geomagnético (2 − Kp máximo)','Composante géomagnétique (2 − Kp maximal)'],
['Геомагнітна складова','Geomagnetic component','Componente geomagnético','Composante géomagnétique'],
['Місячна складова','Lunar component','Componente lunar','Composante lunaire'],
["Календарні позначки враховано за цілу добу. Часові межі окремих позначок не змінюють цей бал.", "Calendar markers apply to the whole day. Individual time boundaries do not change this score.", "Las marcas del calendario se aplican al día completo. Sus límites horarios no cambian esta puntuación.", "Les indications du calendrier comptent pour la journée entière. Leurs limites horaires ne modifient pas ce score."],
["Солах Сомвара: використано вагу Савана Сомвара +1; відповідність назв не підтверджена.", "Solah Somvara uses the Savana Somvara weight +1; the name mapping is unconfirmed.", "Solah Somvara usa el peso +1 de Savana Somvara; la equivalencia de nombres no está confirmada.", "Solah Somvara utilise le poids +1 de Savana Somvara ; la correspondance des noms reste non confirmée."],
["Пітру Пакша: вага джерела +1; легенда водночас застерігає від нових матеріальних справ.", "Pitru Paksha has source weight +1; the legend also cautions against new material ventures.", "Pitru Paksha tiene peso +1 en la fuente; la leyenda también desaconseja nuevas iniciativas materiales.", "Pitru Paksha a un poids de +1 dans la source ; la légende déconseille aussi les nouvelles entreprises matérielles."],

['Пурніма (за календарем)','Purnima (calendar designation)','Purnima (según el calendario)','Purnima (selon le calendrier)'],
['Складова затемнення','Eclipse component','Componente del eclipse','Composante de l’éclipse'],
['Оцінка додатна, але в календарі є позначки з мінусом: ','The score is positive, but the calendar has negative contributions: ','La puntuación es positiva, pero el calendario contiene contribuciones negativas: ','Le score est positif, mais le calendrier contient des contributions négatives : '],
['Як читати SkyRhythm','How to read SkyRhythm','Cómo interpretar SkyRhythm','Comment lire SkyRhythm'],
['Оцінка −3…+3 поєднує Kp NOAA та складові традиційного календаря. Її точність щодо подій не підтверджена.','The −3 to +3 score combines NOAA Kp with traditional calendar factors. Its accuracy in predicting events has not been established.','La puntuación de −3 a +3 combina el Kp de NOAA con factores del calendario tradicional. Su precisión para predecir acontecimientos no está demostrada.','Le score de −3 à +3 associe le Kp de la NOAA aux facteurs du calendrier traditionnel. Sa précision pour prédire des événements n’est pas établie.'],
['Перевіряйте дату й стан джерел. Доба моделі та час плану — за Києвом. «Чому така оцінка» показує внески; «План і щоденник» зберігає ваш власний план і підсумок.','Check the date and source status. The model day and planned times use Kyiv time. “Why this score” shows contributions; the planner and journal store your own plans and outcomes.','Comprueba la fecha y el estado de las fuentes. El día del modelo y los horarios del plan usan la hora de Kyiv. «Por qué esta puntuación» muestra las contribuciones; el planificador y el diario guardan tus planes y resultados.','Vérifiez la date et l’état des sources. Le jour du modèle et les horaires du programme suivent l’heure de Kyiv. « Pourquoi ce score » présente les contributions ; l’agenda et le journal conservent vos projets et vos résultats.'],
['Зрозуміло','Got it','Entendido','Compris'],
['ПАНЧАНГА · П’ЯТЬ СКЛАДОВИХ ДНЯ','PANCHANGA · FIVE COMPONENTS OF THE DAY','PANCHANGA · CINCO COMPONENTES DEL DÍA','PANCHANGA · CINQ COMPOSANTES DU JOUR'],
['Ритми неба','Sky rhythms','Ritmos del cielo','Rythmes du ciel'],
['Сонце, Місяць і переходи традиційного календаря.','The Sun, the Moon and traditional calendar transitions.','El Sol, la Luna y las transiciones del calendario tradicional.','Le Soleil, la Lune et les transitions du calendrier traditionnel.'],
['Складові обраного дня','Selected day’s components','Componentes del día elegido','Composantes du jour choisi'],
['Завантаження календарних складових…','Loading calendar components…','Cargando componentes del calendario…','Chargement des composantes du calendrier…'],
['на початок календарної доби','at the start of the calendar day','al inicio del día del calendario','au début du jour calendaire'],
['зараз','now','ahora','maintenant'],
['Київ','Kyiv','Kyiv','Kyiv'],
['Тітхі · місячний день','Tithi · lunar day','Tithi · día lunar','Tithi · jour lunaire'],
['Накшатра · стоянка Місяця','Nakshatra · lunar mansion','Nakshatra · mansión lunar','Nakshatra · demeure lunaire'],
['Йога · сума довгот','Yoga · sum of longitudes','Yoga · suma de longitudes','Yoga · somme des longitudes'],
['Карана · півтітхі','Karana · half a tithi','Karana · medio tithi','Karana · demi-tithi'],
['Вара · день тижня','Vara · weekday','Vara · día de la semana','Vara · jour de la semaine'],
['Найближчий перехід: ','Next transition: ','Próxima transición: ','Prochaine transition : '],
[' о ',' at ',' a las ',' à '],
['Подальших переходів у цій добі немає.','No further transitions this calendar day.','No hay más transiciones en este día del calendario.','Aucune autre transition durant ce jour calendaire.'],
['Локальний розрахунковий календар. Звірку цієї дати з державним джерелом ще не виконано.','Locally calculated calendar. This date has not yet been checked against a government source.','Calendario calculado localmente. Esta fecha aún no se ha contrastado con una fuente gubernamental.','Calendrier calculé localement. Cette date n’a pas encore été comparée à une source gouvernementale.'],
['Для обраної дати повні складові недоступні. Значення іншого дня не підставляються.','Complete components are unavailable for the selected date. Values from another day are not substituted.','Los componentes completos no están disponibles para la fecha elegida. No se sustituyen por valores de otro día.','Les composantes complètes ne sont pas disponibles pour la date choisie. Les valeurs d’un autre jour ne sont pas utilisées.'],
['Відкрити Панчангу сьогодні →','Open today’s Panchanga →','Abrir el Panchanga de hoy →','Ouvrir le Panchanga du jour →'],
['ТЕМИ КАЛЕНДАРЯ','CALENDAR TOPICS','TEMAS DEL CALENDARIO','THÈMES DU CALENDRIER'],
['Позначки календаря цього дня','This day’s calendar symbols','Símbolos del calendario de este día','Symboles du calendrier de ce jour'],
['Календарні теми ще недоступні','Calendar topics not yet available','Temas del calendario aún no disponibles','Thèmes du calendrier pas encore disponibles'],
['Пояснення тем дня','About the day’s topics','Sobre los temas del día','Explication des thèmes du jour'],
['За традиційним календарем джерела. Це не гарантія результату й не медична рекомендація.','Based on the source’s traditional calendar. This is not a guarantee of an outcome or medical advice.','Basado en el calendario tradicional de la fuente. No garantiza resultados ni constituye una recomendación médica.','Selon le calendrier traditionnel de la source. Ce n’est ni une garantie de résultat ni un conseil médical.'],
['Чому саме так','See the explanation','Ver la explicación','Voir l’explication'],
['Підібрати дату для справи','Pick a date for a task','Elegir fecha para una tarea','Choisir une date pour une tâche'],
['Порівняти оцінки','Compare scores','Comparar puntuaciones','Comparer les scores'],
['Мій ритм','My journal','Mi diario','Mon journal'],
['Ваші нотатки й підсумки плану. Персонального прогнозу поки немає.','Your notes and plan outcomes. No personal forecast is available yet.','Tus notas y resultados del plan. Aún no hay una previsión personal.','Vos notes et bilans. Aucune prévision personnelle n’est encore disponible.'],
['Відкрити мій план','Open my plan','Abrir mi plan','Ouvrir mon programme'],
['Підсумок дня','Daily reflection','Balance del día','Bilan du jour'],
['Оцінка за формулою джерела. Прогностичну точність щодо подій ще не підтверджено.','Score calculated using the source formula. Predictive accuracy for events has not been established.','Puntuación calculada con la fórmula de la fuente. La precisión predictiva de acontecimientos no está demostrada.','Score calculé avec la formule de la source. La précision prédictive concernant les événements n’est pas établie.'],
['Налаштування','Settings','Ajustes','Réglages'],
['Оформлення','Appearance','Apariencia','Apparence'],
['Нічне небо (темне)','Night sky (dark)','Cielo nocturno (oscuro)','Ciel nocturne (sombre)'],
['Світла тема для цього оформлення ще в роботі; класичний вигляд («Ще» → «Класичний вигляд») має світлу.','A light theme for this design is still in progress; the classic layout (More → Classic layout) has one.','El tema claro de este diseño aún está en desarrollo; el diseño clásico (Más → Diseño clásico) lo tiene.','Le thème clair de ce design est en cours ; la mise en page classique (Plus → Mise en page classique) en a un.'],
['Як у системі','System setting','Según el sistema','Selon le système'],
['Світле','Light','Claro','Clair'],
['Темне','Dark','Oscuro','Sombre'],
['Оформлення збережено.','Appearance saved.','Apariencia guardada.','Apparence enregistrée.'],
['Оформлення змінено на цей сеанс; сховище недоступне.','Appearance changed for this session; storage unavailable.','Apariencia cambiada para esta sesión; almacenamiento no disponible.','Apparence modifiée pour cette session ; stockage indisponible.'],
['Ваші дані','Your data','Tus datos','Vos données'],
['Записи залишаються на цьому пристрої. Збережіть копію перед очищенням.','Records stay on this device. Save a copy before clearing them.','Los registros permanecen en este dispositivo. Guarda una copia antes de borrarlos.','Les données restent sur cet appareil. Enregistrez une copie avant de les effacer.'],
['Експортувати дані','Export data','Exportar datos','Exporter les données'],
['Очистити мої дані','Clear my data','Borrar mis datos','Effacer mes données'],
['Календарні складові','Calendar components','Componentes del calendario','Composantes du calendrier'],
['Внесок прогнозного Kp','Forecast Kp contribution','Contribución del Kp previsto','Contribution du Kp prévu'],
['Добовий максимум: ','Daily maximum: ','Máximo diario: ','Maximum quotidien : '],
[' · доба ',' · day in ',' · día en ',' · journée selon '],
['Повне покриття тригодинними NOAA-слотами.','Complete coverage with three-hour NOAA slots.','Cobertura completa con intervalos de tres horas de NOAA.','Couverture complète par intervalles NOAA de trois heures.'],
['Резерв: 27-денний прогноз за добу UTC; це не максимум локальної доби.','Fallback: 27-day outlook for the UTC day; this is not the local-day maximum.','Alternativa: previsión a 27 días para el día UTC; no es el máximo del día local.','Solution de repli : prévisions à 27 jours selon le jour UTC ; ce n’est pas le maximum du jour local.'],
['Внесок у формулу: ','Contribution to the formula: ','Contribución a la fórmula: ','Contribution à la formule : '],
['Сума до перетворення: ','Sum before conversion: ','Suma antes de la conversión: ','Somme avant conversion : '],
['Фізичний показник і календарні складові поєднані правилом моделі; причинний вплив на події не підтверджено.','The physical index and calendar components are combined by the model rule; a causal effect on events has not been established.','El índice físico y los componentes del calendario se combinan según la regla del modelo; no se ha demostrado un efecto causal sobre los acontecimientos.','L’indice physique et les composantes du calendrier sont combinés selon la règle du modèle ; aucun effet causal sur les événements n’est établi.'],
['Ненульових внесків немає.','No non-zero contributions.','No hay contribuciones distintas de cero.','Aucune contribution non nulle.'],
['Розклад складових у цьому знімку недоступний.','Component breakdown unavailable in this snapshot.','Desglose de componentes no disponible en esta captura de datos.','Détail des composantes indisponible dans cet instantané.'],
['Порівняння з експертним джерелом','Comparison with the expert source','Comparación con la fuente experta','Comparaison avec la source experte'],
['Експертне джерело: ','Expert source: ','Fuente experta: ','Source experte : '],
['Формула та календарні дані мають спільне походження. Збіг не є незалежним підтвердженням точності.','The formula and calendar data share the same origin. Agreement is not independent evidence of accuracy.','La fórmula y los datos del calendario tienen el mismo origen. La coincidencia no es una prueba independiente de precisión.','La formule et les données du calendrier ont une origine commune. Leur concordance n’est pas une preuve indépendante de précision.'],
['Розраховано: ','Calculated: ','Calculado: ','Calculé : '],
['NOAA отримано: ','NOAA retrieved: ','NOAA obtenido: ','NOAA récupéré : '],
['NOAA випущено: ','NOAA issued: ','NOAA emitido: ','NOAA publié : '],
['Час випуску у джерелі відсутній.','The source has no issue timestamp.','La fuente no indica la hora de emisión.','L’heure de publication n’est pas fournie par la source.'],
['Час показано для Europe/Kyiv. Покриття знімка: ','Times shown in Europe/Kyiv. Snapshot coverage through: ','Horas en Europe/Kyiv. Cobertura de los datos hasta: ','Heures selon Europe/Kyiv. Données couvertes jusqu’au : '],
['Остання збережена оцінка: ','Last saved score: ','Última puntuación guardada: ','Dernier score enregistré : '],
['не вказано','not specified','no indicado','non précisé'],
['не уточнена','unspecified','sin especificar','non précisée'],
['немає','none','ninguno','aucun'],
['Найближчі 14 днів','Next 14 days','Próximos 14 días','14 prochains jours'],
['Наступні дні','Following days','Días siguientes','Jours suivants'],
['Короткий прогноз · 3-годинні слоти','Short forecast · 3-hour slots','Previsión a corto plazo · intervalos de 3 horas','Prévisions à court terme · intervalles de 3 heures'],
['Орієнтир · 27-денний NOAA outlook','Reference · NOAA 27-day outlook','Referencia · previsión NOAA a 27 días','Repère · prévisions NOAA à 27 jours'],
['Фізичний горизонт не визначений','Physical forecast range unspecified','Alcance de la previsión física sin especificar','Horizon des prévisions physiques non précisé'],
['Порівняйте оцінки та джерело фізичного прогнозу. Далекий орієнтир має інший горизонт, ніж короткий прогноз.','Compare scores and physical forecast sources. The long-range outlook differs from the short forecast.','Compara las puntuaciones y las fuentes de la previsión física. La perspectiva a largo plazo difiere de la previsión a corto plazo.','Comparez les scores et les sources des prévisions physiques. Les perspectives à long terme diffèrent des prévisions à court terme.'],
['Знайдіть дати з потрібними позначками традиційного календаря. Це пошук тем, а не рейтинг найкращих днів.','Find dates with the traditional calendar symbols you need. This is a topic search, not a ranking of the best days.','Busca fechas con los símbolos del calendario tradicional que te interesan. Es una búsqueda por temas, no una clasificación de los mejores días.','Trouvez les dates portant les symboles du calendrier traditionnel qui vous intéressent. Il s’agit d’une recherche par thème, pas d’un classement des meilleurs jours.'],
['Усі теми','All topics','Todos los temas','Tous les thèmes'],
['Навчання','Learning','Aprendizaje','Apprentissage'],
['Подорожі','Travel','Viajes','Voyages'],
['Догляд','Personal care','Cuidado personal','Soins personnels'],
['Планування','Planning','Planificación','Planification'],
['Комунікація','Communication','Comunicación','Communication'],
['27 дат. Натисніть дату для пояснення.','27 dates. Select a date for an explanation.','27 fechas. Elige una fecha para ver la explicación.','27 dates. Sélectionnez une date pour voir l’explication.'],
['Дат із цією позначкою: ','Dates with this symbol: ','Fechas con este símbolo: ','Dates portant ce symbole : '],
['Оцінка може бути відсутня або застаріла.','The score may be missing or out of date.','La puntuación puede faltar o estar desactualizada.','Le score peut être absent ou périmé.'],
['На цих 27 датах такої позначки немає в доступних даних. Нижче залишаються деталі обраної дати.','This symbol is absent from the available data for these 27 dates. The selected date’s details remain below.','Este símbolo no aparece en los datos disponibles para estas 27 fechas. Debajo se mantienen los detalles de la fecha elegida.','Ce symbole est absent des données disponibles pour ces 27 dates. Les détails de la date sélectionnée restent affichés ci-dessous.'],
['січня','January','enero','janvier'],['лютого','February','febrero','février'],['березня','March','marzo','mars'],['квітня','April','abril','avril'],['травня','May','mayo','mai'],['червня','June','junio','juin'],['липня','July','julio','juillet'],['серпня','August','agosto','août'],['вересня','September','septiembre','septembre'],['жовтня','October','octubre','octobre'],['листопада','November','noviembre','novembre'],['грудня','December','diciembre','décembre'],
['понеділок','Monday','lunes','lundi'],['вівторок','Tuesday','martes','mardi'],['середа','Wednesday','miércoles','mercredi'],['четвер','Thursday','jueves','jeudi'],['п’ятниця','Friday','viernes','vendredi'],['субота','Saturday','sábado','samedi'],['неділя','Sunday','domingo','dimanche']
]);
NRLocale.register([
['Небо. Час. Твій ритм.','Sky, time and your daily plans.','El cielo, el tiempo y tus planes diarios.','Le ciel, le temps et vos projets quotidiens.'],
['SkyRhythm','SkyRhythm','SkyRhythm','SkyRhythm'],
['Ритм дня · Джйотіш · Планети · Космічна погода','Daily planning · Jyotish · Planets · Space weather','Planificación diaria · Jyotish · Planetas · Clima espacial','Organisation quotidienne · Jyotish · Planètes · Météo spatiale'],
['Який сьогодні день — за небом і космічною погодою','What kind of day it is — by the sky and space weather','Qué tipo de día es, según el cielo y el clima espacial','Quel genre de journée — selon le ciel et la météo spatiale'],
['Небо сьогодні','Sky today','El cielo hoy','Le ciel aujourd’hui'],
['Сьогодні','Today','Hoy','Aujourd’hui'],['Панчанга','Panchanga','Panchanga','Panchanga'],['Прогноз','Forecast','Previsión','Prévisions'],['Календар','Calendar','Calendario','Calendrier'],['Ще','More','Más','Plus'],['Навігація','Navigation','Navegación','Navigation'],['Концепція','About','Acerca de','À propos'],['Основні розділи застосунку','Main app sections','Secciones principales','Rubriques principales'],
['Прогноз на день, 7 і 27 днів','Forecast for one day, 7 or 27 days','Previsión para un día, 7 o 27 días','Prévisions sur un jour, 7 ou 27 jours'],
['Тема календаря','Calendar topic','Tema del calendario','Thème du calendrier'],['Дати за темою','Dates by topic','Fechas por tema','Dates par thème'],['Ваш день','Your day','Tu día','Votre journée'],['Оцінки та горизонт прогнозу','Scores and forecast range','Puntuaciones y alcance de la previsión','Scores et horizon des prévisions'],
['Мова інтерфейсу: українська.','Interface language: English.','Idioma de la interfaz: español.','Langue de l’interface : français.'],
['Дати моделі та час планів: Europe/Kyiv. Часовий пояс пристрою: ','Model dates and planned times: Europe/Kyiv. Device time zone: ','Fechas del modelo y horarios del plan: Europe/Kyiv. Zona horaria del dispositivo: ','Dates du modèle et horaires des projets : Europe/Kyiv. Fuseau horaire de l’appareil : '],
['Місцева доба може відрізнятися.','Your local calendar day may differ.','El día local puede ser distinto.','Le jour local peut être différent.'],
['жовт.','Oct','oct','oct.'],['лист.','Nov','nov','nov.'],['вер.','Sep','sept','sept.'],[' р.',' ', ' ', ' '],
['Календарний контекст · Венера','Calendar context · Venus','Contexto del calendario · Venus','Contexte du calendrier · Vénus'],
['Дата в ретроградному періоді','Date within the retrograde period','Fecha dentro del período retrógrado','Date comprise dans la période rétrograde'],
['Зараз період триває.','The period is currently in progress.','El período está en curso.','La période est actuellement en cours.'],
['Зараз період ще не почався.','The period has not started yet.','El período aún no ha comenzado.','La période n’a pas encore commencé.'],
['Зараз період уже завершився.','The period has ended.','El período ya ha terminado.','La période est terminée.'],
['Попереду ретроградний період','Retrograde period ahead','Próximo período retrógrado','Période rétrograde à venir'],
['Цього дня починається ретроградний період','The retrograde period starts on this date','El período retrógrado comienza en esta fecha','La période rétrograde commence à cette date'],
['Цього дня завершується ретроградний період','The retrograde period ends on this date','El período retrógrado termina en esta fecha','La période rétrograde se termine à cette date'],
['Час приблизний до хвилини.','Times are approximate to the minute.','Horas aproximadas al minuto.','Heures approximatives à la minute près.'],
['Традиційна тема: перегляд стосунків, цінностей і покупок. Цей блок не додає бала й не змінює рішення дня.','Traditional theme: reviewing relationships, values and purchases. This section adds no points and does not change the day’s assessment.','Tema tradicional: revisar relaciones, valores y compras. Esta sección no añade puntos ni modifica la valoración del día.','Thème traditionnel : réexaminer les relations, les valeurs et les achats. Cette rubrique n’ajoute aucun point et ne modifie pas l’évaluation du jour.'],
['Практичні підказки та джерело','Practical prompts and source','Sugerencias prácticas y fuente','Pistes pratiques et source'],
['За бажанням використайте як привід для перевірки планів:','If useful, take this as a prompt to review your plans:','Si te resulta útil, úsalo como una oportunidad para revisar tus planes:','Si cela vous est utile, profitez-en pour revoir vos projets :'],
['Обговоріть спільні плани й незавершені питання без поспіху.','Discuss shared plans and outstanding issues without rushing.','Habla de los planes compartidos y los asuntos pendientes sin prisas.','Discutez sans précipitation des projets communs et des questions en suspens.'],
['Перегляньте бюджет та умови запланованих покупок.','Review your budget and the terms of planned purchases.','Revisa tu presupuesto y las condiciones de las compras previstas.','Revoyez votre budget et les conditions des achats prévus.'],
['Для гардероба чи оселі спочатку оцініть, що вже маєте і що справді потрібно.','For clothing or your home, first consider what you already have and what you actually need.','Para tu ropa o tu hogar, revisa primero lo que ya tienes y lo que realmente necesitas.','Pour votre garde-robe ou votre logement, évaluez d’abord ce que vous avez et ce dont vous avez réellement besoin.'],
['Це не підстава переносити весілля, відмовлятися від потрібної покупки чи змінювати медичні рішення.','This is not a reason to postpone a wedding, forgo a necessary purchase or change medical decisions.','Esto no justifica aplazar una boda, renunciar a una compra necesaria ni cambiar decisiones médicas.','Ce n’est pas une raison pour reporter un mariage, renoncer à un achat nécessaire ou modifier des décisions médicales.'],
['Дати: наявний календар станцій Swiss Ephemeris. Астрологічне тлумачення — окремий традиційний контекст; його точність щодо життєвих подій у нашій системі не підтверджено.','Dates: the existing Swiss Ephemeris station calendar. Astrological interpretation is a separate traditional context; its accuracy for life events has not been established in our system.','Fechas: calendario de estaciones existente de Swiss Ephemeris. La interpretación astrológica es un contexto tradicional separado; su precisión sobre acontecimientos vitales no se ha demostrado en nuestro sistema.','Dates : calendrier existant des stations Swiss Ephemeris. L’interprétation astrologique constitue un contexte traditionnel distinct ; sa précision concernant les événements de la vie n’est pas établie dans notre système.'],
['Дані для цієї дати не підтверджені. Поза покриттям календаря стан Венери не визначаємо.','Data for this date is unverified. We do not determine Venus’s state outside calendar coverage.','Los datos de esta fecha no están verificados. No determinamos el estado de Venus fuera de la cobertura del calendario.','Les données de cette date ne sont pas vérifiées. L’état de Vénus n’est pas déterminé hors de la couverture du calendrier.'],
['Пітру Пакша','Pitru Paksha','Pitru Paksha','Pitru Paksha'],['Серце','Heart symbol','Símbolo de corazón','Symbole du cœur'],['Екадаші','Ekadashi','Ekadashi','Ekadashi'],['Наваратрі','Navaratri','Navaratri','Navaratri'],['1 місячний день','First lunar day','Primer día lunar','Premier jour lunaire'],['Мішень','Target symbol','Símbolo de diana','Symbole de cible'],['Амавасья, день мертвих','Amavasya, remembrance of the departed','Amavasya, recuerdo de los difuntos','Amavasya, souvenir des défunts'],['День порожні руки, несприятливий','Empty Hands day, unfavourable','Día de las manos vacías, desfavorable','Jour des mains vides, défavorable'],['Сурья Санкранті Перехід Сонця із знаку в інший','Surya Sankranti, Sun entering another sign','Surya Sankranti, entrada del Sol en otro signo','Surya Sankranti, passage du Soleil dans un autre signe'],['Тричі  трикутник','Triple triangle','Triple triángulo','Triple triangle'],['Ромб','Diamond symbol','Símbolo de rombo','Symbole du losange'],['Зелена печатка','Green seal','Sello verde','Sceau vert'],['День Божого провидіння','Divine Providence day','Día de la Providencia divina','Jour de la Providence divine'],['Рука','Hand symbol','Símbolo de mano','Symbole de la main'],['Гучномовець','Loudspeaker symbol','Símbolo de altavoz','Symbole du haut-parleur'],['Віджая дашамі','Vijayadashami','Vijayadashami','Vijayadashami'],['Акаша трітья','Akasha Tritiya','Akasha Tritiya','Akasha Tritiya'],['Гуру Пурніма','Guru Purnima','Guru Purnima','Guru Purnima'],['Прадош врат','Pradosh Vrat','Pradosh Vrat','Pradosh Vrat'],['Санкашті','Sankashti','Sankashti','Sankashti'],['Ганеша чатуртхі','Ganesha Chaturthi','Ganesha Chaturthi','Ganesha Chaturthi'],['Вінаяка','Vinayaka','Vinayaka','Vinayaka'],['Діпавалі','Deepavali','Deepavali','Deepavali'],['Махашиваратрі','Mahashivaratri','Mahashivaratri','Mahashivaratri'],['Масік Шиваратрі','Masik Shivaratri','Masik Shivaratri','Masik Shivaratri'],['Савана Сомвара','Savana Somvara','Savana Somvara','Savana Somvara'],['Шприц','Syringe symbol','Símbolo de jeringa','Symbole de seringue'],['Хрест','Cross symbol','Símbolo de cruz','Symbole de croix'],['Книги','Books symbol','Símbolo de libros','Symbole des livres'],['Сукня','Dress symbol','Símbolo de vestido','Symbole de robe'],['Таблетка','Tablet symbol','Símbolo de comprimido','Symbole de comprimé'],
['легенда джерела, с. ','source legend, p. ','leyenda de la fuente, p. ','légende de la source, p. '],
['період вшанування предків; джерело застерігає від нових матеріальних справ','period of honouring ancestors; the source cautions against new material ventures','período de homenaje a los antepasados; la fuente advierte contra nuevas iniciativas materiales','période consacrée aux ancêtres ; la source déconseille de nouvelles entreprises matérielles'],
['позначка підтримки нових починань у трактуванні джерела','symbol supporting new beginnings in the source interpretation','símbolo favorable a nuevos comienzos según la fuente','symbole favorable aux nouveaux départs selon la source'],
['традиційний день пожертви й посту; не рекомендація обмежувати харчування','traditional day of charity and fasting; not a recommendation to restrict food','día tradicional de donación y ayuno; no se recomienda restringir la alimentación','jour traditionnel de don et de jeûne ; il ne s’agit pas d’une recommandation de restriction alimentaire'],
['свято вшанування Богині-Матері','festival honouring the Mother Goddess','festividad en honor a la Diosa Madre','fête en l’honneur de la Déesse-Mère'],
['планування й постановка цілей','planning and setting goals','planificación y definición de objetivos','planification et définition d’objectifs'],
['30-й місячний день; вшанування померлих родичів','30th lunar day; remembrance of deceased relatives','día lunar 30; recuerdo de los familiares fallecidos','30e jour lunaire ; souvenir des proches décédés'],
['застереження джерела щодо нових справ; тема прибирання й очищення','source caution about new ventures; cleaning and clearing theme','advertencia de la fuente sobre nuevas iniciativas; tema de limpieza y depuración','mise en garde de la source concernant les nouvelles entreprises ; thème du nettoyage et de la purification'],
['перехід Сонця між знаками; застереження джерела щодо нових проєктів','the Sun’s passage between signs; source caution about new projects','paso del Sol entre signos; advertencia de la fuente sobre nuevos proyectos','passage du Soleil entre les signes ; mise en garde de la source concernant les nouveaux projets'],
['застереження джерела про повторення роботи тричі','source warning about work being repeated three times','advertencia de la fuente sobre repetir el trabajo tres veces','avertissement de la source concernant un travail répété trois fois'],
['застереження джерела про повторення роботи','source warning about repeating work','advertencia de la fuente sobre repetir el trabajo','avertissement de la source concernant la répétition du travail'],
['позначка нових починань у трактуванні джерела','new beginnings symbol in the source interpretation','símbolo de nuevos comienzos según la fuente','symbole de nouveaux départs selon la source'],
['; заявлену ним імовірність успіху не підтверджено','; its stated likelihood of success is unverified','; la probabilidad de éxito que afirma no está verificada',' ; la probabilité de réussite annoncée n’est pas vérifiée'],
['увага до подій дня','attention to the day’s events','atención a los acontecimientos del día','attention portée aux événements du jour'],
['реклама й маркетингові проєкти','advertising and marketing projects','publicidad y proyectos de marketing','publicité et projets de marketing'],
['свято, пов’язане в джерелі з починаннями','festival associated by the source with new beginnings','festividad que la fuente asocia con nuevos comienzos','fête associée par la source aux nouveaux départs'],
['позначка починань у трактуванні джерела','beginnings symbol in the source interpretation','símbolo de comienzos según la fuente','symbole de commencements selon la source'],
['вшанування вчителів і вдячність','honouring teachers and expressing gratitude','homenaje a los maestros y gratitud','hommage aux enseignants et gratitude'],
['традиційний піст і вшанування Шиви','traditional fasting and honouring Shiva','ayuno tradicional y homenaje a Shiva','jeûne traditionnel et hommage à Shiva'],
['традиційне вшанування Ганеші','traditional honouring of Ganesha','homenaje tradicional a Ganesha','hommage traditionnel à Ganesha'],
['свято народження Ганеші','festival celebrating Ganesha’s birth','festividad del nacimiento de Ganesha','fête de la naissance de Ganesha'],
['свято світла й добра','festival of light and goodness','festividad de la luz y el bien','fête de la lumière et du bien'],
['ніч вшанування Шиви','night honouring Shiva','noche en honor a Shiva','nuit en l’honneur de Shiva'],
['традиційний піст на честь Шиви','traditional fast in honour of Shiva','ayuno tradicional en honor a Shiva','jeûne traditionnel en l’honneur de Shiva'],
['цикл шістнадцяти понеділків; назву зіставлено з Солах Сомвара Врат','cycle of sixteen Mondays; name matched to Solah Somvar Vrat','ciclo de dieciséis lunes; nombre vinculado a Solah Somvar Vrat','cycle de seize lundis ; nom rapproché de Solah Somvar Vrat'],
['позначка хірургічних втручань у джерелі; не медична рекомендація','surgery symbol in the source; not medical advice','símbolo de intervenciones quirúrgicas en la fuente; no es un consejo médico','symbole des interventions chirurgicales dans la source ; ce n’est pas un conseil médical'],
['відвідування лікаря й початок лікування; позначка календаря, не медична рекомендація','doctor visits and starting treatment; a calendar symbol, not medical advice','visitas al médico e inicio del tratamiento; símbolo del calendario, no consejo médico','consultation médicale et début de traitement ; symbole du calendrier, pas un conseil médical'],
['початок навчання','starting a course of study','inicio de los estudios','début d’un apprentissage'],
['перше вдягання нового одягу','first wearing of new clothes','primer uso de ropa nueva','premier port de vêtements neufs'],
['лікування; позначка календаря, не обіцянка одужання','treatment; a calendar symbol, not a promise of recovery','tratamiento; símbolo del calendario, no promesa de recuperación','traitement ; symbole du calendrier, pas une promesse de guérison']
]);

NRLocale.register([['Немає даних для поточного моменту','No data for the current time','No hay datos para este momento','Aucune donnée pour le moment présent']]);

NRLocale.register([
  [
    "Джйотіш · календар дня",
    "Jyotish · daily calendar",
    "Jyotish · calendario del día",
    "Jyotish · calendrier du jour"
  ],
  [
    "Референс на схід сонця",
    "Sunrise reference",
    "Referencia al amanecer",
    "Référence au lever du soleil"
  ],
  [
    "час відліку",
    "reference time",
    "hora de referencia",
    "heure de référence"
  ],
  [
    "Тіхі/Вара/Накшатра/Йога/Карана розраховані на реальний астрономічний схід сонця для поточного дня (ведична конвенція), НЕ на 12:00 UTC — попередній текст тут був неточним (fp236).",
    "Tithi/Vara/Nakshatra/Yoga/Karana are calculated at the actual astronomical sunrise for the current day (Vedic convention), NOT at 12:00 UTC. The previous text here was inaccurate (fp236).",
    "Tithi/Vara/Nakshatra/Yoga/Karana se calculan para el amanecer astronómico real del día actual (convención védica), NO para las 12:00 UTC. El texto anterior era impreciso (fp236).",
    "Tithi/Vara/Nakshatra/Yoga/Karana sont calculés au lever astronomique réel du soleil du jour (convention védique), et NON à 12 h UTC. Le texte précédent était inexact (fp236)."
  ],
  [
    "Зовнішні календарі можуть показувати іншу тітхі, якщо рахують \"на момент запиту\" або \"опівночі\" (західна конвенція) — це методологічна різниця, не обов’язково помилка.",
    "External calendars may show a different Tithi when calculated at the time of the request or at midnight (Western convention). This is a difference in method, not necessarily an error.",
    "Otros calendarios pueden mostrar un Tithi distinto si calculan para el momento de la consulta o la medianoche (convención occidental). Es una diferencia de método, no necesariamente un error.",
    "D’autres calendriers peuvent afficher un Tithi différent s’ils calculent au moment de la consultation ou à minuit (convention occidentale). Il s’agit d’une différence de méthode, pas nécessairement d’une erreur."
  ],
  [
    "Для поточної хори дивись блок «Планетарний ритм» у картці особистого прогнозу.",
    "For the current Hora, see Planetary rhythm in the personal forecast card.",
    "Para ver la Hora actual, consulta Ritmo planetario en la tarjeta de previsión personal.",
    "Pour la Hora actuelle, consultez Rythme planétaire dans la fiche de prévision personnelle."
  ],
  [
    "локальні часові вікна",
    "local time windows",
    "franjas horarias locales",
    "créneaux horaires locaux"
  ],
  [
    "Традиційний шар: показано",
    "Traditional layer: shown",
    "Capa tradicional: visible",
    "Couche traditionnelle : affichée"
  ],
  [
    "Традиційний шар: приховано",
    "Traditional layer: hidden",
    "Capa tradicional: oculta",
    "Couche traditionnelle : masquée"
  ],
  [
    "ВРАХОВАНО ОДИН РАЗ",
    "COUNTED ONCE",
    "CONTABILIZADO UNA VEZ",
    "COMPTÉ UNE SEULE FOIS"
  ],
  [
    "один Pᵢ",
    "one Pᵢ",
    "un solo Pᵢ",
    "un seul Pᵢ"
  ],
  [
    "ЛОКАЛЬНІ ВІКНА",
    "LOCAL WINDOWS",
    "FRANJAS LOCALES",
    "CRÉNEAUX LOCAUX"
  ],
  [
    "обмежують слот, не весь день",
    "constrain the time slot, not the whole day",
    "limitan la franja horaria, no el día entero",
    "limitent le créneau, pas toute la journée"
  ],
  [
    "ЛИШЕ ІНФОРМАЦІЙНО",
    "INFORMATION ONLY",
    "SOLO INFORMATIVO",
    "À TITRE INFORMATIF"
  ],
  [
    "Що це означає і які межі?",
    "What does this mean and what are the limits?",
    "¿Qué significa y cuáles son sus límites?",
    "Que signifie cela et quelles sont les limites ?"
  ],
  [
    "Традиційний календарний шар, розрахований для локального дня від астрономічного сходу сонця з урахуванням timezone/DST. Це не другий прогноз і не фізична причинність. Головний оперативний стан має пріоритет; персональні D1/D9 і Dasha не активовані до окремої перевірки ephemeris та privacy-gate.",
    "Traditional calendar layer calculated for the local day from astronomical sunrise, accounting for the time zone and daylight saving time. It is not a second forecast or a claim of physical causation. The main operational status takes priority; personal D1/D9 and Dasha remain inactive pending separate ephemeris and privacy checks.",
    "Capa del calendario tradicional calculada para el día local a partir del amanecer astronómico, teniendo en cuenta la zona horaria y el horario de verano. No es una segunda previsión ni una afirmación de causalidad física. El estado operativo principal tiene prioridad; D1/D9 y Dasha personales siguen inactivos hasta verificar por separado las efemérides y la privacidad.",
    "Couche du calendrier traditionnel calculée pour le jour local à partir du lever astronomique du soleil, en tenant compte du fuseau horaire et de l’heure d’été. Ce n’est ni une seconde prévision ni une affirmation de causalité physique. L’état opérationnel principal est prioritaire ; les D1/D9 et Dasha personnels restent inactifs avant des vérifications distinctes des éphémérides et de la confidentialité."
  ],
  [
    "Найближчі критичні вікна",
    "Upcoming critical windows",
    "Próximas franjas críticas",
    "Prochains créneaux critiques"
  ],
  [
    "Сонячний ритм",
    "Solar rhythm",
    "Ritmo solar",
    "Rythme solaire"
  ],
  [
    "канон BPHS",
    "BPHS canon",
    "canon BPHS",
    "canon BPHS"
  ],
  [
    "Чогхадія — 16 муhурт дня (натиснути)",
    "Choghadiya — 16 daily Muhurtas (open)",
    "Choghadiya — 16 Muhurtas del día (abrir)",
    "Choghadiya — 16 Muhurtas du jour (ouvrir)"
  ],
  [
    "деталі",
    "details",
    "detalles",
    "détails"
  ],
  [
    "Тітхі",
    "Tithi",
    "Tithi",
    "Tithi"
  ],
  [
    "Накшатра",
    "Nakshatra",
    "Nakshatra",
    "Nakshatra"
  ],
  [
    "Зміна",
    "Transition",
    "Cambio",
    "Transition"
  ],
  [
    "Ретроградність",
    "Retrograde motion",
    "Movimiento retrógrado",
    "Mouvement rétrograde"
  ],
  [
    "Тиск:",
    "Pressure:",
    "Presión:",
    "Pression :"
  ],
  [
    "Космічна карта",
    "Sky map",
    "Mapa celeste",
    "Carte du ciel"
  ],
  [
    "Панчанга: що підтримує і що обмежує",
    "Panchanga: supporting and limiting factors",
    "Panchanga: factores de apoyo y limitaciones",
    "Panchanga : facteurs favorables et limites"
  ],
  [
    "Не загальний verdict дня. Це список локальних обмежень/підтримки з Tithi · Vara · Nakshatra · Yoga · Hora",
    "This is not an overall verdict for the day. It lists local limiting and supporting factors from Tithi · Vara · Nakshatra · Yoga · Hora",
    "No es una valoración global del día. Enumera limitaciones y factores de apoyo locales de Tithi · Vara · Nakshatra · Yoga · Hora",
    "Ce n’est pas une évaluation globale du jour. Cette liste présente les limites et les facteurs favorables locaux issus de Tithi · Vara · Nakshatra · Yoga · Hora"
  ],
  [
    "розгорнути",
    "expand",
    "desplegar",
    "développer"
  ],
  [
    "Зовнішні календарі можуть показувати іншу тітхі, якщо рахують \"на момент запиту\" або \"опівночі\" (західна конвенція) — це методологічна різниця, не обов'язково помилка.",
    "External calendars may show a different Tithi when calculated at the time of the request or at midnight (Western convention). This is a difference in method, not necessarily an error.",
    "Otros calendarios pueden mostrar un Tithi distinto si calculan para el momento de la consulta o la medianoche (convención occidental). Es una diferencia de método, no necesariamente un error.",
    "D’autres calendriers peuvent afficher un Tithi différent s’ils calculent au moment de la consultation ou à minuit (convention occidentale). Il s’agit d’une différence de méthode, pas nécessairement d’une erreur."
  ]
]);

NRLocale.register([["Є розбіжність із державним календарем. ", "There is a difference from the government calendar. ", "Hay una discrepancia con el calendario oficial. ", "Une différence existe avec le calendrier officiel. "], ["Звірено переходів: ", "Transitions compared: ", "Transiciones comparadas: ", "Transitions comparées : "], ["найбільша різниця: ", "largest difference: ", "diferencia máxima: ", "écart maximal : "], [" с. ", " seconds. ", " segundos. ", " secondes. "], ["Дата звірки — за індійським календарем; моменти переведено в UTC. Це не перевірка прогнозу особистих подій.", "Comparison date follows the Indian calendar; times are converted to UTC. This does not validate predictions of personal events.", "La fecha de comparación sigue el calendario indio; las horas se convierten a UTC. Esto no valida predicciones de acontecimientos personales.", "La date de comparaison suit le calendrier indien ; les heures sont converties en UTC. Cela ne valide pas les prévisions d’événements personnels."]]);

NRLocale.register([
  [
    "ЩО ДІЄ",
    "CURRENT COMPONENT",
    "COMPONENTE ACTUAL",
    "COMPOSANTE ACTUELLE"
  ],
  [
    "ВПЛИВ",
    "ASSOCIATION",
    "ASOCIACIÓN",
    "ASSOCIATION"
  ],
  [
    "КРАЩА ДІЯ",
    "SUGGESTED ACTION",
    "ACCIÓN SUGERIDA",
    "ACTION SUGGÉRÉE"
  ],
  [
    "місячний день",
    "lunar day",
    "día lunar",
    "jour lunaire"
  ],
  [
    "Що це: час, за який Місяць відстає від Сонця на 12°.",
    "Definition: the interval during which the Moon–Sun angular separation changes by 12°.",
    "Definición: intervalo en el que la separación angular entre la Luna y el Sol cambia 12°.",
    "Définition : intervalle pendant lequel la séparation angulaire entre la Lune et le Soleil change de 12°."
  ],
  [
    "Місяць = 30 тітхі (15 світлих + 15 темних).",
    "A lunar month contains 30 Tithis (15 waxing and 15 waning).",
    "Un mes lunar contiene 30 Tithis (15 crecientes y 15 menguantes).",
    "Un mois lunaire comprend 30 Tithis (15 croissants et 15 décroissants)."
  ],
  [
    "Місячний день:",
    "Lunar day:",
    "Día lunar:",
    "Jour lunaire :"
  ],
  [
    " з 30",
    " of 30",
    " de 30",
    " sur 30"
  ],
  [
    "(темна половина) — Місяць убуває, енергія йде до завершення.",
    "(waning half) — the Moon wanes; traditionally associated with completion.",
    "(mitad menguante): la Luna mengua; se asocia tradicionalmente con la finalización.",
    "(moitié décroissante) : la Lune décroît ; traditionnellement associée à l’achèvement."
  ],
  [
    "Тип:",
    "Type:",
    "Tipo:",
    "Type :"
  ],
  [
    "Бхадра (добра) — добра для будівництва і навчання.",
    "Bhadra (good) — traditionally favours construction and study.",
    "Bhadra (buena): tradicionalmente favorable para la construcción y el estudio.",
    "Bhadra (bonne) : traditionnellement favorable à la construction et à l’étude."
  ],
  [
    "Бхадра",
    "Bhadra",
    "Bhadra",
    "Bhadra"
  ],
  [
    "Вплив:",
    "Traditional association:",
    "Asociación tradicional:",
    "Association traditionnelle :"
  ],
  [
    "сприятливий",
    "favourable",
    "favorable",
    "favorable"
  ],
  [
    "сприятлива",
    "favourable",
    "favorable",
    "favorable"
  ],
  [
    "Локальна асоціація (оперативний стан невідомий):",
    "Local association (operational status unknown):",
    "Asociación local (estado operativo desconocido):",
    "Association locale (état opérationnel inconnu) :"
  ],
  [
    "Локальна асоціація:",
    "Local association:",
    "Asociación local:",
    "Association locale :"
  ],
  [
    "Партнерства, планування",
    "Partnerships, planning",
    "Colaboraciones, planificación",
    "Partenariats, planification"
  ],
  [
    "день тижня",
    "day of the week",
    "día de la semana",
    "jour de la semaine"
  ],
  [
    "Що це: кожен день керується планетою-регентом.",
    "Definition: each day has a traditional planetary ruler.",
    "Definición: cada día tiene un regente planetario tradicional.",
    "Définition : chaque jour possède un maître planétaire traditionnel."
  ],
  [
    "Будха (Меркурій)",
    "Budha (Mercury)",
    "Budha (Mercurio)",
    "Budha (Mercure)"
  ],
  [
    "Вплив на когнітивний стан:",
    "Model’s cognitive-state association:",
    "Asociación del modelo con el estado cognitivo:",
    "Association du modèle avec l’état cognitif :"
  ],
  [
    "Будхавара",
    "Budhavara",
    "Budhavara",
    "Budhavara"
  ],
  [
    "Комунікації, переговори, планування",
    "Communication, negotiations, planning",
    "Comunicación, negociaciones, planificación",
    "Communication, négociations, planification"
  ],
  [
    "місячна стоянка",
    "lunar mansion",
    "mansión lunar",
    "demeure lunaire"
  ],
  [
    "Що це: 27 стоянок Місяця по 13°20' екліптики.",
    "Definition: 27 lunar mansions, each spanning 13°20′ of the ecliptic.",
    "Definición: 27 mansiones lunares de 13°20′ de la eclíptica cada una.",
    "Définition : 27 demeures lunaires couvrant chacune 13°20′ de l’écliptique."
  ],
  [
    "Місяць проходить всі 27 за ~27,3 доби.",
    "The Moon passes through all 27 in about 27.3 days.",
    "La Luna recorre las 27 en unos 27,3 días.",
    "La Lune parcourt les 27 en environ 27,3 jours."
  ],
  [
    "Регент:",
    "Ruler:",
    "Regente:",
    "Maître :"
  ],
  [
    "регент:",
    "ruler:",
    "regente:",
    "maître :"
  ],
  [
    "Кету",
    "Ketu",
    "Ketu",
    "Ketu"
  ],
  [
    "Жорстка — деструктивна енергія; обережно.",
    "Fierce — traditionally described as destructive energy; caution.",
    "Feroz: descrita tradicionalmente como energía destructiva; prudencia.",
    "Féroce : traditionnellement décrite comme une énergie destructrice ; prudence."
  ],
  [
    "Жорстка",
    "Fierce",
    "Feroz",
    "Féroce"
  ],
  [
    "Вплив на:",
    "Traditional association with:",
    "Asociación tradicional con:",
    "Association traditionnelle avec :"
  ],
  [
    "Народжені сьогодні традиційно проходять Mool Shanti (27-денний ритуал).",
    "Those born today traditionally undergo Mool Shanti (a 27-day ritual).",
    "Quienes nacen hoy tradicionalmente participan en Mool Shanti (ritual de 27 días).",
    "Les personnes nées ce jour suivent traditionnellement Mool Shanti (rituel de 27 jours)."
  ],
  [
    "Півень",
    "Rooster",
    "Gallo",
    "Coq"
  ],
  [
    "Якості:",
    "Qualities:",
    "Cualidades:",
    "Qualités :"
  ],
  [
    "Активність, голос, влада",
    "Activity, voice, authority",
    "Actividad, voz, autoridad",
    "Activité, voix, autorité"
  ],
  [
    "Реструктуризація, ліквідація, жорсткі рішення",
    "Restructuring, closure, firm decisions",
    "Reestructuración, cierre, decisiones firmes",
    "Restructuration, clôture, décisions fermes"
  ],
  [
    "сонячно-місячний резонанс",
    "Sun–Moon combination",
    "combinación del Sol y la Luna",
    "combinaison Soleil–Lune"
  ],
  [
    "Що це: 27 Yoga = якість резонансу коли сума довгот Сонця і Місяця\nдосягає кратного 13°20'. Середня тривалість ~24 год.",
    "Definition: 27 Yogas divide the sum of the Sun’s and Moon’s longitudes into intervals of 13°20′. Average duration: about 24 hours.",
    "Definición: 27 Yogas dividen la suma de las longitudes del Sol y la Luna en intervalos de 13°20′. Duración media: unas 24 horas.",
    "Définition : 27 Yogas divisent la somme des longitudes du Soleil et de la Lune en intervalles de 13°20′. Durée moyenne : environ 24 heures."
  ],
  [
    "резонанс Сонце–Місяць",
    "Sun–Moon combination",
    "combinación Sol–Luna",
    "combinaison Soleil–Lune"
  ],
  [
    "Загальна сприятливість",
    "General favourability",
    "Carácter favorable general",
    "Caractère favorable général"
  ],
  [
    "половина місячного дня",
    "half a lunar day",
    "medio día lunar",
    "moitié d’un jour lunaire"
  ],
  [
    "Що це: час, за який ΔL збільшується на 6°. Кожна тітхі = 2 карани.",
    "Definition: the interval during which ΔL increases by 6°. Each Tithi contains two Karanas.",
    "Definición: intervalo en el que ΔL aumenta 6°. Cada Tithi contiene dos Karanas.",
    "Définition : intervalle pendant lequel ΔL augmente de 6°. Chaque Tithi contient deux Karanas."
  ],
  [
    "Призначення:",
    "Traditional purpose:",
    "Uso tradicional:",
    "Usage traditionnel :"
  ],
  [
    "Союзи",
    "Alliances",
    "Alianzas",
    "Alliances"
  ],
  [
    "Каулава",
    "Kaulava",
    "Kaulava",
    "Kaulava"
  ],
  [
    "Рухома",
    "Movable",
    "Móvil",
    "Mobile"
  ],
  [
    "несприятливий інтервал",
    "traditionally unfavourable interval",
    "intervalo tradicionalmente desfavorable",
    "intervalle traditionnellement défavorable"
  ],
  [
    "Що це: 90-хвилинний щоденний інтервал Північного вузла Місяця.",
    "Definition in the legacy text: a daily 90-minute interval associated with the Moon’s north node.",
    "Definición del texto anterior: intervalo diario de 90 minutos asociado al nodo norte de la Luna.",
    "Définition du texte historique : intervalle quotidien de 90 minutes associé au nœud nord de la Lune."
  ],
  [
    "Традиційно: не починати нових справ і бойових завдань.",
    "Traditional interpretation: do not begin new activities or combat tasks.",
    "Interpretación tradicional: no iniciar actividades nuevas ni tareas de combate.",
    "Interprétation traditionnelle : ne pas commencer de nouvelles activités ni de missions de combat."
  ],
  [
    "Зараз неактивний.",
    "Currently inactive.",
    "Actualmente inactivo.",
    "Actuellement inactif."
  ],
  [
    "минув",
    "ended",
    "finalizado",
    "terminé"
  ],
  [
    "Минув",
    "Ended",
    "Finalizado",
    "Terminé"
  ],
  [
    "минула",
    "ended",
    "finalizada",
    "terminée"
  ],
  [
    "Канонічне інаусп. вікно (Surya Siddhanta).",
    "Traditional unfavourable window (Surya Siddhanta).",
    "Franja tradicional desfavorable (Surya Siddhanta).",
    "Créneau traditionnel défavorable (Surya Siddhanta)."
  ],
  [
    "Друге за важливістю після Rahu Kalam.",
    "Second in importance after Rahu Kalam.",
    "Segundo en importancia después de Rahu Kalam.",
    "Deuxième en importance après Rahu Kalam."
  ],
  [
    "Канонічне інаусп. вікно (син Сатурна).",
    "Traditional unfavourable window (son of Saturn).",
    "Franja tradicional desfavorable (hijo de Saturno).",
    "Créneau traditionnel défavorable (fils de Saturne)."
  ],
  [
    "Третє після Rahu+Yama.",
    "Third after Rahu and Yama.",
    "Tercero después de Rahu y Yama.",
    "Troisième après Rahu et Yama."
  ],
  [
    "усі astro-фактори",
    "all astronomical factors",
    "todos los factores astronómicos",
    "tous les facteurs astronomiques"
  ],
  [
    "сумарний контекст близький до нейтрального;",
    "overall context is close to neutral;",
    "el contexto general es casi neutro;",
    "le contexte global est proche de la neutralité ;"
  ],
  [
    "лише один локальний внесок",
    "only one local contribution",
    "solo una contribución local",
    "une seule contribution locale"
  ],
  [
    "фон зараз",
    "current background",
    "contexto actual",
    "contexte actuel"
  ],
  [
    "подій не знайдено",
    "no events found",
    "no se encontraron eventos",
    "aucun événement trouvé"
  ],
  [
    "Дипломатія, нові союзи",
    "Diplomacy, new alliances",
    "Diplomacia, nuevas alianzas",
    "Diplomatie, nouvelles alliances"
  ],
  [
    "Формула:",
    "Formula:",
    "Fórmula:",
    "Formule :"
  ],
  [
    "3-day Pᵢ середнє",
    "3-day mean Pᵢ",
    "Pᵢ medio de 3 días",
    "Pᵢ moyen sur 3 jours"
  ],
  [
    "панчанга підтримує",
    "supportive Panchanga context",
    "contexto favorable del Panchanga",
    "contexte favorable du Panchanga"
  ],
  [
    "Пурніма",
    "Purnima",
    "Purnima",
    "Purnima"
  ],
  [
    "розрахунок",
    "calculation",
    "cálculo",
    "calcul"
  ],
  [
    "нейтрально · не дата свята",
    "neutral · not a festival date",
    "neutro · no es la fecha de una festividad",
    "neutre · pas une date de fête"
  ],
  [
    "Екадаші (11-та тітхі)",
    "Ekadashi (11th Tithi)",
    "Ekadashi (11.º Tithi)",
    "Ekadashi (11e Tithi)"
  ],
  [
    "Амавасья: модель G знижує оцінку цього дня (розрахунковий фактор, не висновок про стан людини).",
    "Amavasya: the G model lowers this day's score (a computed factor, not a statement about a person's condition).",
    "Amavasya: el modelo G reduce la puntuación de este día (factor calculado, no una afirmación sobre el estado de una persona).",
    "Amavasya : le modèle G abaisse la note de ce jour (facteur calculé, pas un constat sur l'état d'une personne)."
  ],
  [
    "Екадаші: календарний фактор моделі G знижує оцінку дня.",
    "Ekadashi: a calendar factor of the G model lowers the day's score.",
    "Ekadashi: un factor de calendario del modelo G reduce la puntuación del día.",
    "Ekadashi : un facteur calendaire du modèle G abaisse la note du jour."
  ],
  [
    "день відречення",
    "day of renunciation",
    "día de renuncia",
    "jour de renoncement"
  ],
  [
    "важливі справи відкласти",
    "postpone important activities",
    "aplazar actividades importantes",
    "reporter les activités importantes"
  ],
  [
    "через ",
    "in ",
    "en ",
    "dans "
  ],
  [
    "Схід",
    "Sunrise",
    "Amanecer",
    "Lever du soleil"
  ],
  [
    "Захід",
    "Sunset",
    "Atardecer",
    "Coucher du soleil"
  ],
  [
    "Полудень",
    "Solar noon",
    "Mediodía solar",
    "Midi solaire"
  ],
  [
    "(день ",
    "(daylight ",
    "(luz diurna ",
    "(jour "
  ],
  [
    "Сонце",
    "Sun",
    "Sol",
    "Soleil"
  ],
  [
    "Місяць",
    "Moon",
    "Luna",
    "Lune"
  ],
  [
    " у ",
    " in ",
    " en ",
    " en "
  ],
  [
    "Діва",
    "Virgo",
    "Virgo",
    "Vierge"
  ],
  [
    "Лев",
    "Leo",
    "Leo",
    "Lion"
  ],
  [
    "Меркурій",
    "Mercury",
    "Mercurio",
    "Mercure"
  ],
  [
    "Венера",
    "Venus",
    "Venus",
    "Vénus"
  ],
  [
    "Марс",
    "Mars",
    "Marte",
    "Mars"
  ],
  [
    "Юпітер",
    "Jupiter",
    "Júpiter",
    "Jupiter"
  ],
  [
    "Сатурн",
    "Saturn",
    "Saturno",
    "Saturne"
  ],
  [
    "Абгіджит-мухурта",
    "Abhijit Muhurta",
    "Abhijit Muhurta",
    "Abhijit Muhurta"
  ],
  [
    "Зараз:",
    "Now:",
    "Ahora:",
    "Maintenant :"
  ],
  [
    "Лабха",
    "Labh",
    "Labh",
    "Labh"
  ],
  [
    "Амріта",
    "Amrita",
    "Amrita",
    "Amrita"
  ],
  [
    "Кала",
    "Kala",
    "Kala",
    "Kala"
  ],
  [
    "Шубха",
    "Shubha",
    "Shubha",
    "Shubha"
  ],
  [
    "Рога",
    "Roga",
    "Roga",
    "Roga"
  ],
  [
    "Удвега",
    "Udvega",
    "Udvega",
    "Udvega"
  ],
  [
    "Чара",
    "Chara",
    "Chara",
    "Chara"
  ],
  [
    "(не в G)",
    "(not included in G)",
    "(no incluido en G)",
    "(non inclus dans G)"
  ],
  [
    "успіх, прибуток; гарне для бізнесу",
    "success, profit; traditionally favourable for business",
    "éxito, beneficio; tradicionalmente favorable para los negocios",
    "réussite, profit ; traditionnellement favorable aux affaires"
  ],
  [
    "нектар; найкраще для важливих справ",
    "nectar; traditionally preferred for important activities",
    "néctar; tradicionalmente preferido para actividades importantes",
    "nectar ; traditionnellement privilégié pour les activités importantes"
  ],
  [
    "смерть; найгірше — лише захисні дії",
    "death; traditionally least favourable — defensive activities only",
    "muerte; tradicionalmente lo menos favorable: solo actividades defensivas",
    "mort ; traditionnellement le moins favorable : activités défensives uniquement"
  ],
  [
    "сприятливо; для добрих починань",
    "favourable; for positive beginnings",
    "favorable; para buenos comienzos",
    "favorable ; pour de bons débuts"
  ],
  [
    "хвороба; не починати нове",
    "illness; traditionally avoid new beginnings",
    "enfermedad; tradicionalmente se evitan nuevos comienzos",
    "maladie ; traditionnellement, éviter de nouveaux débuts"
  ],
  [
    "тривога; уникати важливих рішень",
    "anxiety; traditionally avoid important decisions",
    "inquietud; tradicionalmente se evitan decisiones importantes",
    "inquiétude ; traditionnellement, éviter les décisions importantes"
  ],
  [
    "нейтрально; підходить для подорожей",
    "neutral; traditionally suitable for travel",
    "neutro; tradicionalmente adecuado para viajar",
    "neutre ; traditionnellement adapté aux voyages"
  ],
  [
    "ДЕНЬ",
    "DAY",
    "DÍA",
    "JOUR"
  ],
  [
    "НІЧ",
    "NIGHT",
    "NOCHE",
    "NUIT"
  ],
  [
    "поточний слот",
    "current time slot",
    "franja actual",
    "créneau actuel"
  ],
  [
    "наступн. схід",
    "next sunrise",
    "próximo amanecer",
    "prochain lever du soleil"
  ],
  [
    "Місцевий схід Сонця",
    "Local sunrise",
    "Amanecer local",
    "Lever local du soleil"
  ],
  [
    "Місцевий захід Сонця",
    "Local sunset",
    "Atardecer local",
    "Coucher local du soleil"
  ],
  [
    "Тривалість світлового дня",
    "Daylight duration",
    "Duración de la luz diurna",
    "Durée du jour"
  ],
  [
    "НЕ входить у canonical G/Pᵢ/final_score",
    "NOT included in canonical G/Pᵢ/final_score",
    "NO se incluye en G/Pᵢ/final_score canónico",
    "NON inclus dans G/Pᵢ/final_score canonique"
  ],
  [
    "Планета",
    "Planet",
    "Planeta",
    "Planète"
  ],
  [
    "Статус",
    "Status",
    "Estado",
    "État"
  ],
  [
    "Оперативний контекст",
    "Operational context",
    "Contexto operativo",
    "Contexte opérationnel"
  ],
  [
    "норма",
    "direct",
    "directo",
    "direct"
  ],
  [
    "ретро",
    "retrograde",
    "retrógrado",
    "rétrograde"
  ],
  [
    "Звʼязок, планування",
    "Communication, planning",
    "Comunicación, planificación",
    "Communication, planification"
  ],
  [
    "Логістичні затримки, тертя",
    "Logistical delays, friction",
    "Retrasos logísticos, fricciones",
    "Retards logistiques, frictions"
  ],
  [
    "Активна дія, атака",
    "Active action, attack",
    "Acción activa, ataque",
    "Action active, attaque"
  ],
  [
    "Сприятливо, захист",
    "Favourability, protection",
    "Carácter favorable, protección",
    "Caractère favorable, protection"
  ],
  [
    "Виснаження, уповільнення",
    "Exhaustion, slowing down",
    "Agotamiento, ralentización",
    "Épuisement, ralentissement"
  ],
  [
    "Планетний внесок",
    "Planetary contribution",
    "Contribución planetaria",
    "Contribution planétaire"
  ],
  [
    "не впливає на G автоматично",
    "does not automatically affect G",
    "no afecta automáticamente a G",
    "n’affecte pas automatiquement G"
  ],
  [
    "Сумарний astro-контекст близький до нейтрального",
    "Overall astronomical context is close to neutral",
    "El contexto astronómico general es casi neutro",
    "Le contexte astronomique global est proche de la neutralité"
  ],
  [
    "лише один компонент",
    "only one component",
    "solo un componente",
    "une seule composante"
  ],
  [
    "часові вікна перевіряються окремо.",
    "time windows are checked separately.",
    "las franjas horarias se comprueban por separado.",
    "les créneaux horaires sont vérifiés séparément."
  ],
  [
    "фактор у G_raw, не окремий прогноз",
    "a factor in G_raw, not a separate forecast",
    "un factor de G_raw, no una previsión independiente",
    "un facteur de G_raw, pas une prévision distincte"
  ],
  [
    "Краща дія: тримати стандартний режим без різких маневрів.",
    "Suggested action: maintain a normal routine without abrupt changes.",
    "Acción sugerida: mantener la rutina habitual sin cambios bruscos.",
    "Action suggérée : conserver une routine habituelle sans changements brusques."
  ],
  [
    "Серп, що спадає",
    "Waning crescent",
    "Luna menguante",
    "Dernier croissant"
  ],
  [
    "освітл.",
    "illuminated",
    "iluminado",
    "éclairé"
  ],
  [
    "Несприятлива",
    "Unfavourable",
    "Desfavorable",
    "Défavorable"
  ],
  [
    "Активні:",
    "Active:",
    "Activos:",
    "Actifs :"
  ],
  [
    "час приблизний до хвилини",
    "time approximate to the minute",
    "hora aproximada al minuto",
    "heure approximative à la minute"
  ],
  [
    "календарний контекст · score_effect=0 · не команда для дії",
    "calendar context · score_effect=0 · not an instruction to act",
    "contexto del calendario · score_effect=0 · no es una instrucción para actuar",
    "contexte calendaire · score_effect=0 · aucune instruction d’agir"
  ],
  [
    "Календарний контекст Jyotish",
    "Jyotish calendar context",
    "Contexto del calendario Jyotish",
    "Contexte calendaire Jyotish"
  ],
  [
    "традиційні назви та часові вікна показані в картці нижче. score_effect=0; цей шар не дозволяє і не забороняє дії. Оперативне рішення — лише у головному блоці.",
    "traditional names and time windows appear in the card below. score_effect=0; this layer neither authorizes nor prohibits action. The operational decision appears only in the main panel.",
    "los nombres tradicionales y las franjas horarias aparecen en la tarjeta inferior. score_effect=0; esta capa no autoriza ni prohíbe actuar. La decisión operativa aparece únicamente en el panel principal.",
    "les noms traditionnels et les créneaux horaires figurent dans la fiche ci-dessous. score_effect=0 ; cette couche n’autorise ni n’interdit d’agir. La décision opérationnelle figure uniquement dans le panneau principal."
  ]
]);

NRLocale.register([
  [
    " дн.",
    " days",
    " días",
    " jours"
  ],
  [
    "Середнє арифметичне Pᵢ за наступні 3 дні (включно з сьогодні).",
    "Arithmetic mean Pᵢ over the next three days, including today.",
    "Media aritmética de Pᵢ para los próximos tres días, incluido hoy.",
    "Moyenne arithmétique de Pᵢ sur les trois prochains jours, aujourd’hui compris."
  ],
  [
    "має статус R&D/advisory і ще не підтверджений prospective-вибіркою.",
    "has R&D/advisory status and has not yet been validated using a prospective sample.",
    "tiene carácter de investigación/orientación y aún no se ha validado con una muestra prospectiva.",
    "a un statut de recherche/indicatif et n’a pas encore été validé sur un échantillon prospectif."
  ],
  [
    "Виключення: tіхі",
    "Exceptions: Tithi",
    "Excepciones: Tithi",
    "Exceptions : Tithi"
  ],
  [
    "обробляються в eᵢ (events), не в Pᵢ.",
    "are handled in eᵢ (events), not Pᵢ.",
    "se procesan en eᵢ (eventos), no en Pᵢ.",
    "sont traités dans eᵢ (événements), pas dans Pᵢ."
  ],
  [
    "Класифікація 3-day середнього:",
    "Classification of the 3-day mean:",
    "Clasificación de la media de 3 días:",
    "Classification de la moyenne sur 3 jours :"
  ],
  [
    "панчанга заважає",
    "limiting Panchanga context",
    "contexto limitante del Panchanga",
    "contexte limitant du Panchanga"
  ],
  [
    "інше    — «нейтральна»",
    "otherwise — neutral",
    "en otro caso: neutro",
    "sinon : neutre"
  ],
  [
    "Джерело: live sunrise reference (astronomy-engine), не frozen engine_scores.",
    "Source: live sunrise reference (astronomy-engine), not frozen engine_scores.",
    "Fuente: referencia calculada al amanecer (astronomy-engine), no engine_scores congelados.",
    "Source : référence calculée au lever du soleil (astronomy-engine), pas les engine_scores figés."
  ],
  [
    "Surya Rashi — поточний sidereal знак Сонця (Lahiri ayanamsha). Сонце міняє знак раз на ~30 днів.",
    "Surya Rashi — current sidereal sign of the Sun (Lahiri ayanamsha). The Sun changes sign about every 30 days.",
    "Surya Rashi: signo sideral actual del Sol (ayanamsha Lahiri). El Sol cambia de signo aproximadamente cada 30 días.",
    "Surya Rashi : signe sidéral actuel du Soleil (ayanamsha Lahiri). Le Soleil change de signe environ tous les 30 jours."
  ],
  [
    "Chandra Rashi — поточний sidereal знак Місяця. Міняється кожні ~2.5 дні. Базис для janma rashi і muhurta.",
    "Chandra Rashi — current sidereal sign of the Moon. Changes about every 2.5 days. A basis for janma rashi and muhurta.",
    "Chandra Rashi: signo sideral actual de la Luna. Cambia aproximadamente cada 2,5 días. Base para janma rashi y muhurta.",
    "Chandra Rashi : signe sidéral actuel de la Lune. Change environ tous les 2,5 jours. Base du janma rashi et du muhurta."
  ],
  [
    "Abhijit Muhurta = solar noon ± 24хв. Універсально-сприятливе вікно дня (за BPHS, окрім вівторка). Ідеально для важливих рішень, переговорів, запусків.",
    "Abhijit Muhurta = solar noon ± 24 min. Traditionally described as a generally favourable window (BPHS, except Tuesday), for important decisions, negotiations and launches.",
    "Abhijit Muhurta = mediodía solar ± 24 min. Tradicionalmente descrito como una franja generalmente favorable (BPHS, excepto el martes), para decisiones importantes, negociaciones y lanzamientos.",
    "Abhijit Muhurta = midi solaire ± 24 min. Traditionnellement décrit comme un créneau généralement favorable (BPHS, sauf le mardi), pour les décisions importantes, négociations et lancements."
  ],
  [
    "Brahma Muhurta = 2 muhurta до сходу (~96-48 хв до sunrise). Канон BPHS — найкращий час для духовних практик, медитації, навчання.",
    "Brahma Muhurta = 2 muhurtas before sunrise (about 96–48 min before sunrise). BPHS tradition favours this time for spiritual practice, meditation and study.",
    "Brahma Muhurta = 2 muhurtas antes del amanecer (unos 96–48 min antes). La tradición BPHS favorece este periodo para prácticas espirituales, meditación y estudio.",
    "Brahma Muhurta = 2 muhurtas avant le lever du soleil (environ 96–48 min avant). La tradition BPHS privilégie ce moment pour les pratiques spirituelles, la méditation et l’étude."
  ],
  [
    "Vijaya Muhurta = 11-та з 15 muhurta дня. Канон Drik Panchang — \"час перемоги\": успіх у складних задачах, переговори, дебати.",
    "Vijaya Muhurta = the 11th of 15 daytime muhurtas. Drik Panchang tradition calls it the time of victory, associated with difficult tasks, negotiations and debates.",
    "Vijaya Muhurta = el 11.º de los 15 muhurtas diurnos. La tradición de Drik Panchang lo llama tiempo de victoria y lo asocia con tareas difíciles, negociaciones y debates.",
    "Vijaya Muhurta = le 11e des 15 muhurtas diurnes. La tradition de Drik Panchang le nomme temps de la victoire et l’associe aux tâches difficiles, négociations et débats."
  ],
  [
    "Godhuli Muhurta = sunset ± 0.5 muhurta. \"Час повернення корови\" — gentle transitions, вечірні молитви, зосередження.",
    "Godhuli Muhurta = sunset ± 0.5 muhurta. The time when cows return: gentle transitions, evening prayers and concentration.",
    "Godhuli Muhurta = atardecer ± 0,5 muhurta. La hora del regreso de las vacas: transiciones suaves, oraciones vespertinas y concentración.",
    "Godhuli Muhurta = coucher du soleil ± 0,5 muhurta. L’heure du retour des vaches : transitions douces, prières du soir et concentration."
  ],
  [
    "Nishita Muhurta = 8-ма з 15 night muhurta (північна). Канон BPHS — meditation, midnight rituals, deep contemplation.",
    "Nishita Muhurta = the 8th of 15 nighttime muhurtas (around midnight). BPHS tradition: meditation, midnight rituals and deep contemplation.",
    "Nishita Muhurta = el 8.º de los 15 muhurtas nocturnos (hacia medianoche). Tradición BPHS: meditación, rituales de medianoche y contemplación profunda.",
    "Nishita Muhurta = le 8e des 15 muhurtas nocturnes (vers minuit). Tradition BPHS : méditation, rituels de minuit et contemplation profonde."
  ]
]);

NRLocale.register([
  [
    "Тайтіла",
    "Taitila",
    "Taitila",
    "Taitila"
  ],
  [
    "Ваніджа",
    "Vanija",
    "Vanija",
    "Vanija"
  ],
  [
    "Гараджа",
    "Garaja",
    "Garaja",
    "Garaja"
  ],
  [
    "Вішті",
    "Vishti",
    "Vishti",
    "Vishti"
  ],
  [
    "Балава",
    "Balava",
    "Balava",
    "Balava"
  ],
  [
    "Бава",
    "Bava",
    "Bava",
    "Bava"
  ],
  [
    "Нага",
    "Naga",
    "Naga",
    "Naga"
  ],
  [
    "Шакуні",
    "Shakuni",
    "Shakuni",
    "Shakuni"
  ],
  [
    "на сході Сонця",
    "at sunrise",
    "al amanecer",
    "au lever du soleil"
  ],
  [
    "індекс",
    "index",
    "índice",
    "indice"
  ],
  [
    "Договори, весілля",
    "Agreements, weddings",
    "Acuerdos, bodas",
    "Accords, mariages"
  ],
  [
    "Джая (перемога) — добра для початку справ і досягнень.",
    "Jaya (victory) — traditionally favourable for starting activities and achieving goals.",
    "Jaya (victoria): tradicionalmente favorable para iniciar actividades y alcanzar objetivos.",
    "Jaya (victoire) : traditionnellement favorable au début des activités et à la réalisation des objectifs."
  ],
  [
    "Джая",
    "Jaya",
    "Jaya",
    "Jaya"
  ],
  [
    "Рікта (порожня) — уникати важливих рішень і активних дій.",
    "Rikta (empty) — traditionally associated with avoiding important decisions and active undertakings.",
    "Rikta (vacía): tradicionalmente asociada con evitar decisiones importantes y acciones activas.",
    "Rikta (vide) : traditionnellement associée à l’évitement des décisions importantes et des actions actives."
  ],
  [
    "Рікта",
    "Rikta",
    "Rikta",
    "Rikta"
  ],
  [
    "Нанда (радісна) — добра для починань і нових справ.",
    "Nanda (joyful) — traditionally favourable for new beginnings and activities.",
    "Nanda (alegre): tradicionalmente favorable para nuevos comienzos y actividades.",
    "Nanda (joyeuse) : traditionnellement favorable aux nouveaux débuts et activités."
  ],
  [
    "Нанда",
    "Nanda",
    "Nanda",
    "Nanda"
  ],
  [
    "Пурна (повна) — добра для завершення і дипломатії.",
    "Purna (full) — traditionally favourable for completion and diplomacy.",
    "Purna (llena): tradicionalmente favorable para finalizar tareas y para la diplomacia.",
    "Purna (pleine) : traditionnellement favorable à l’achèvement et à la diplomatie."
  ],
  [
    "Пурна",
    "Purna",
    "Purna",
    "Purna"
  ],
  [
    "Стала — добра для довгострокових проєктів.",
    "Fixed — traditionally favourable for long-term projects.",
    "Fija: tradicionalmente favorable para proyectos a largo plazo.",
    "Fixe : traditionnellement favorable aux projets à long terme."
  ],
  [
    "Легка — підходить для радісних і легких справ.",
    "Light — traditionally suited to joyful and light activities.",
    "Ligera: tradicionalmente adecuada para actividades alegres y ligeras.",
    "Légère : traditionnellement adaptée aux activités joyeuses et légères."
  ],
  [
    "М'яка",
    "Gentle",
    "Suave",
    "Douce"
  ],
  [
    "Стала",
    "Fixed",
    "Fija",
    "Fixe"
  ],
  [
    "Легка",
    "Light",
    "Ligera",
    "Légère"
  ],
  [
    "Змішана — нейтральна, помірна активність.",
    "Mixed — neutral, moderate activity.",
    "Mixta: neutra, actividad moderada.",
    "Mixte : neutre, activité modérée."
  ],
  [
    "Змішана",
    "Mixed",
    "Mixta",
    "Mixte"
  ],
  [
    "Рухома — добра для переміщень і операцій.",
    "Movable — traditionally favourable for movement and operations.",
    "Móvil: tradicionalmente favorable para desplazamientos y operaciones.",
    "Mobile : traditionnellement favorable aux déplacements et opérations."
  ],
  [
    "(світла половина) — Місяць росте, енергія йде до зростання.",
    "(waxing half) — the Moon waxes; traditionally associated with growth.",
    "(mitad creciente): la Luna crece; tradicionalmente asociada con el crecimiento.",
    "(moitié croissante) : la Lune croît ; traditionnellement associée à la croissance."
  ],
  [
    "Гурувара",
    "Guruvara",
    "Guruvara",
    "Guruvara"
  ],
  [
    "Шукравара",
    "Shukravara",
    "Shukravara",
    "Shukravara"
  ],
  [
    "Шанівара",
    "Shanivara",
    "Shanivara",
    "Shanivara"
  ],
  [
    "Равівара",
    "Ravivara",
    "Ravivara",
    "Ravivara"
  ],
  [
    "Сомавара",
    "Somavara",
    "Somavara",
    "Somavara"
  ],
  [
    "Мангалавара",
    "Mangalavara",
    "Mangalavara",
    "Mangalavara"
  ],
  [
    "Гуру",
    "Guru",
    "Guru",
    "Guru"
  ],
  [
    "Шукра",
    "Shukra",
    "Shukra",
    "Shukra"
  ],
  [
    "Шані",
    "Shani",
    "Shani",
    "Shani"
  ],
  [
    "Сурья",
    "Surya",
    "Surya",
    "Surya"
  ],
  [
    "Чандра",
    "Chandra",
    "Chandra",
    "Chandra"
  ],
  [
    "Мангала",
    "Mangala",
    "Mangala",
    "Mangala"
  ],
  [
    "Раху",
    "Rahu",
    "Rahu",
    "Rahu"
  ],
  [
    "Ворона",
    "Crow",
    "Cuervo",
    "Corbeau"
  ],
  [
    "Павич",
    "Peacock",
    "Pavo real",
    "Paon"
  ],
  [
    "Адаптивність, спостережливість",
    "Adaptability, observation",
    "Adaptabilidad, observación",
    "Adaptabilité, observation"
  ],
  [
    "Краса, мистецтво, гармонія",
    "Beauty, art, harmony",
    "Belleza, arte, armonía",
    "Beauté, art, harmonie"
  ],
  [
    "нейтральний",
    "neutral",
    "neutro",
    "neutre"
  ],
  [
    "Нейтральна",
    "Neutral",
    "Neutra",
    "Neutre"
  ],
  [
    "завтра",
    "tomorrow",
    "mañana",
    "demain"
  ],
  [
    "ще буде",
    "upcoming",
    "próximo",
    "à venir"
  ],
  [
    "сьогодні",
    "today",
    "hoy",
    "aujourd’hui"
  ],
  [
    "сумарний контекст тисне;",
    "overall context is limiting;",
    "el contexto general es limitante;",
    "le contexte global est limitant ;"
  ],
  [
    "сумарний контекст підтримує;",
    "overall context is supportive;",
    "el contexto general es favorable;",
    "le contexte global est favorable ;"
  ],
  [
    "Терези",
    "Libra",
    "Libra",
    "Balance"
  ],
  [
    "Скорпіон",
    "Scorpio",
    "Escorpio",
    "Scorpion"
  ],
  [
    "Стрілець",
    "Sagittarius",
    "Sagitario",
    "Sagittaire"
  ],
  [
    "Козеріг",
    "Capricorn",
    "Capricornio",
    "Capricorne"
  ],
  [
    "Водолій",
    "Aquarius",
    "Acuario",
    "Verseau"
  ],
  [
    "Риби",
    "Pisces",
    "Piscis",
    "Poissons"
  ],
  [
    "Овен",
    "Aries",
    "Aries",
    "Bélier"
  ],
  [
    "Телець",
    "Taurus",
    "Tauro",
    "Taureau"
  ],
  [
    "Близнюки",
    "Gemini",
    "Géminis",
    "Gémeaux"
  ],
  [
    "Рак",
    "Cancer",
    "Cáncer",
    "Cancer"
  ],
  [
    "Зараз активний! Уникати нових операцій.",
    "Active now. Traditional interpretation: avoid starting new operations.",
    "Activo ahora. Interpretación tradicional: evitar iniciar nuevas operaciones.",
    "Actif actuellement. Interprétation traditionnelle : éviter de commencer de nouvelles opérations."
  ],
  [
    "Сприятлива подія",
    "Favourable event",
    "Evento favorable",
    "Événement favorable"
  ],
  [
    "подія знижує",
    "event reduces",
    "el evento reduce",
    "l’événement réduit"
  ],
  [
    "події",
    "events",
    "eventos",
    "événements"
  ],
  [
    "неактивний за",
    "inactive according to",
    "inactivo según",
    "inactif selon"
  ],
  [
    "традиційно вето: уникати важливих активних дій",
    "traditional veto: avoid important active undertakings",
    "veto tradicional: evitar acciones activas importantes",
    "veto traditionnel : éviter les actions actives importantes"
  ],
  [
    "інаусп. зоні",
    "unfavourable zone",
    "zona desfavorable",
    "zone défavorable"
  ],
  [
    "інаусп.",
    "unfavourable",
    "desfavorable",
    "défavorable"
  ],
  [
    "Канон",
    "Tradition",
    "Tradición",
    "Tradition"
  ],
  [
    "уникати весілля, новосілля, бізнес-старту, південних подорожей.",
    "traditionally avoid weddings, housewarmings, business launches and southbound travel.",
    "tradicionalmente se evitan bodas, inauguraciones de casas, nuevos negocios y viajes hacia el sur.",
    "traditionnellement, éviter les mariages, pendaisons de crémaillère, lancements d’activité et voyages vers le sud."
  ],
  [
    "КРИТИЧНА",
    "CRITICAL",
    "CRÍTICA",
    "CRITIQUE"
  ],
  [
    "онбординг",
    "onboarding",
    "incorporación",
    "intégration"
  ],
  [
    "Підготовка, документація",
    "Preparation, documentation",
    "Preparación, documentación",
    "Préparation, documentation"
  ],
  [
    "Стратегія, навчання, менторство, найкращий день",
    "Strategy, study, mentoring; traditionally the best day",
    "Estrategia, estudio, mentoría; tradicionalmente el mejor día",
    "Stratégie, étude, mentorat ; traditionnellement le meilleur jour"
  ],
  [
    "ясність думки",
    "clarity of thought",
    "claridad de pensamiento",
    "clarté de pensée"
  ],
  [
    "Торгівля, логістика",
    "Trade, logistics",
    "Comercio, logística",
    "Commerce, logistique"
  ],
  [
    "Завершення циклів, підсумки",
    "Completing cycles, taking stock",
    "Cerrar ciclos, hacer balance",
    "Clôture des cycles, bilan"
  ],
  [
    "Нетворкінг, відпочинок, креатив",
    "Networking, rest, creativity",
    "Contactos, descanso, creatividad",
    "Réseautage, repos, créativité"
  ],
  [
    "Довгострокові проєкти, будівництво, фундамент",
    "Long-term projects, construction, foundations",
    "Proyectos a largo plazo, construcción, cimientos",
    "Projets à long terme, construction, fondations"
  ],
  [
    "Творчість, знання, навчання",
    "Creativity, knowledge, study",
    "Creatividad, conocimiento, estudio",
    "Créativité, connaissances, étude"
  ],
  [
    "Ритуали",
    "Rituals",
    "Rituales",
    "Rituels"
  ],
  [
    "Аналіз, моніторинг, відпочинок",
    "Analysis, monitoring, rest",
    "Análisis, seguimiento, descanso",
    "Analyse, suivi, repos"
  ],
  [
    "Дисципліна, аудит, довгострокові задачі",
    "Discipline, audit, long-term tasks",
    "Disciplina, auditoría, tareas a largo plazo",
    "Discipline, audit, tâches à long terme"
  ],
  [
    "Легкі завдання, комунікації, нетворкінг",
    "Light tasks, communication, networking",
    "Tareas ligeras, comunicación, contactos",
    "Tâches légères, communication, réseautage"
  ],
  [
    "Лідерство, командування",
    "Leadership, command",
    "Liderazgo, mando",
    "Leadership, commandement"
  ],
  [
    "Небезпечні ситуації — обережно",
    "Dangerous situations — caution",
    "Situaciones peligrosas: prudencia",
    "Situations dangereuses : prudence"
  ],
  [
    "Спонтанні рішення",
    "Spontaneous decisions",
    "Decisiones espontáneas",
    "Décisions spontanées"
  ],
  [
    "Нові проєкти, планування, старт ініціатив",
    "New projects, planning, launching initiatives",
    "Nuevos proyectos, planificación, inicio de iniciativas",
    "Nouveaux projets, planification, lancement d’initiatives"
  ],
  [
    "Лідерство, стратегічні рішення, здоров'я",
    "Leadership, strategic decisions, health",
    "Liderazgo, decisiones estratégicas, salud",
    "Leadership, décisions stratégiques, santé"
  ],
  [
    "Креатив, лікування, дипломатія",
    "Creativity, treatment, diplomacy",
    "Creatividad, tratamiento, diplomacia",
    "Créativité, traitement, diplomatie"
  ],
  [
    "Завершення циклів",
    "Completing cycles",
    "Cerrar ciclos",
    "Clôture des cycles"
  ],
  [
    "Постійні справи",
    "Ongoing activities",
    "Actividades continuas",
    "Activités continues"
  ],
  [
    "Не починати нових операцій",
    "Do not start new operations",
    "No iniciar nuevas operaciones",
    "Ne pas commencer de nouvelles opérations"
  ],
  [
    "Нові починання (руйнівна)",
    "New beginnings (destructive)",
    "Nuevos comienzos (destructiva)",
    "Nouveaux débuts (destructrice)"
  ],
  [
    "Нові бойові завдання, стратегічні рішення",
    "New combat tasks, strategic decisions",
    "Nuevas tareas de combate, decisiones estratégicas",
    "Nouvelles missions de combat, décisions stratégiques"
  ],
  [
    "побудова процесів, логістика",
    "building processes, logistics",
    "creación de procesos, logística",
    "mise en place de processus, logistique"
  ],
  [
    "Інтуїтивні рішення, аналітика, відновлення",
    "Intuitive decisions, analysis, recovery",
    "Decisiones intuitivas, análisis, recuperación",
    "Décisions intuitives, analyse, récupération"
  ],
  [
    "Переміщення, запуски, логістика",
    "Movement, launches, logistics",
    "Desplazamientos, lanzamientos, logística",
    "Déplacements, lancements, logistique"
  ],
  [
    "Уникати всього важливого",
    "Avoid important activities",
    "Evitar actividades importantes",
    "Éviter les activités importantes"
  ],
  [
    "Будь-які наступальні дії",
    "Any offensive actions",
    "Cualquier acción ofensiva",
    "Toute action offensive"
  ],
  [
    "Публічні виступи",
    "Public speaking",
    "Intervenciones públicas",
    "Prises de parole publiques"
  ],
  [
    "сон)",
    "sleep)",
    "sueño)",
    "sommeil)"
  ],
  [
    "Рішучі дії, запуск проєктів, лідерські ініціативи",
    "Decisive action, project launches, leadership initiatives",
    "Acciones decididas, lanzamiento de proyectos, iniciativas de liderazgo",
    "Actions décisives, lancement de projets, initiatives de leadership"
  ],
  [
    "Рішучі дії, дедлайни, конкуренція",
    "Decisive action, deadlines, competition",
    "Acciones decididas, plazos, competencia",
    "Actions décisives, échéances, concurrence"
  ],
  [
    "Будь-які завдання — нейтрально",
    "Any tasks — neutral",
    "Cualquier tarea: neutro",
    "Toutes tâches : neutre"
  ],
  [
    "дружба, координація",
    "friendship, coordination",
    "amistad, coordinación",
    "amitié, coordination"
  ],
  [
    "Рутинні задачі, адміністрування",
    "Routine tasks, administration",
    "Tareas rutinarias, administración",
    "Tâches courantes, administration"
  ],
  [
    "Медогляд, лікування, здоров'я",
    "Medical check-up, treatment, health",
    "Revisión médica, tratamiento, salud",
    "Examen médical, traitement, santé"
  ],
  [
    "Очікування, спостереження",
    "Waiting, observation",
    "Espera, observación",
    "Attente, observation"
  ],
  [
    "Стратегічні рішення, великі угоди",
    "Strategic decisions, major agreements",
    "Decisiones estratégicas, grandes acuerdos",
    "Décisions stratégiques, accords majeurs"
  ],
  [
    "Будь-які активні дії (абсолютне вето)",
    "Any active undertakings (absolute veto)",
    "Cualquier acción activa (veto absoluto)",
    "Toute action active (veto absolu)"
  ],
  [
    "Переговори, дипломатія, лікування",
    "Negotiations, diplomacy, treatment",
    "Negociaciones, diplomacia, tratamiento",
    "Négociations, diplomatie, traitement"
  ],
  [
    "Старт нових операцій",
    "Starting new operations",
    "Inicio de nuevas operaciones",
    "Début de nouvelles opérations"
  ],
  [
    "Фінансові операції",
    "Financial operations",
    "Operaciones financieras",
    "Opérations financières"
  ],
  [
    "Комунікації, нетворкінг, переміщення",
    "Communication, networking, movement",
    "Comunicación, contactos, desplazamientos",
    "Communication, réseautage, déplacements"
  ],
  [
    "краса плану",
    "elegance of the plan",
    "elegancia del plan",
    "élégance du programme"
  ],
  [
    "Логістика, постачання, транспорт",
    "Logistics, supplies, transport",
    "Logística, suministros, transporte",
    "Logistique, approvisionnement, transport"
  ],
  [
    "Оборона, мінімальна активність",
    "Defence, minimal activity",
    "Defensa, actividad mínima",
    "Défense, activité minimale"
  ],
  [
    "Наступ, ризик",
    "Offence, risk",
    "Ofensiva, riesgo",
    "Offensive, risque"
  ],
  [
    "Захист позицій, аудит, оборона",
    "Protecting positions, audit, defence",
    "Protección de posiciones, auditoría, defensa",
    "Protection des positions, audit, défense"
  ],
  [
    "виконання завдань, успіх у справах",
    "completing tasks, success in activities",
    "cumplir tareas, éxito en las actividades",
    "accomplissement des tâches, réussite des activités"
  ],
  [
    "Аналітика, спостереження, аудит",
    "Analysis, observation, audit",
    "Análisis, observación, auditoría",
    "Analyse, observation, audit"
  ],
  [
    "Довгострокові операції, стійкість",
    "Long-term operations, resilience",
    "Operaciones a largo plazo, resiliencia",
    "Opérations à long terme, résilience"
  ],
  [
    "Активні ініціативи",
    "Active initiatives",
    "Iniciativas activas",
    "Initiatives actives"
  ],
  [
    "Угоди, презентації, публічні заяви",
    "Agreements, presentations, public statements",
    "Acuerdos, presentaciones, declaraciones públicas",
    "Accords, présentations, déclarations publiques"
  ],
  [
    "Рутина",
    "Routine",
    "Rutina",
    "Routine"
  ],
  [
    "Конфлікти, ризик",
    "Conflicts, risk",
    "Conflictos, riesgo",
    "Conflits, risque"
  ],
  [
    "Відпочинок, рефлексія, навчання",
    "Rest, reflection, study",
    "Descanso, reflexión, estudio",
    "Repos, réflexion, étude"
  ],
  [
    "стратегічне мислення",
    "strategic thinking",
    "pensamiento estratégico",
    "réflexion stratégique"
  ],
  [
    "Обережна рутина",
    "Cautious routine",
    "Rutina prudente",
    "Routine prudente"
  ],
  [
    "Агресивні дії",
    "Aggressive actions",
    "Acciones agresivas",
    "Actions agressives"
  ],
  [
    "Наступальні дії",
    "Offensive actions",
    "Acciones ofensivas",
    "Actions offensives"
  ],
  [
    "партнерства, логістика",
    "partnerships, logistics",
    "colaboraciones, logística",
    "partenariats, logistique"
  ],
  [
    "Розвиток, навчання, нарощування",
    "Development, study, building capacity",
    "Desarrollo, estudio, aumento de capacidad",
    "Développement, étude, renforcement des capacités"
  ],
  [
    "Координація, комунікації",
    "Coordination, communication",
    "Coordinación, comunicación",
    "Coordination, communication"
  ],
  [
    "Будівництво, зміцнення позицій",
    "Construction, strengthening positions",
    "Construcción, fortalecimiento de posiciones",
    "Construction, renforcement des positions"
  ],
  [
    "Жорсткі рішення, реструктуризація, захист",
    "Firm decisions, restructuring, protection",
    "Decisiones firmes, reestructuración, protección",
    "Décisions fermes, restructuration, protection"
  ],
  [
    "Оборона",
    "Defence",
    "Defensa",
    "Défense"
  ],
  [
    "Наступ, насильство",
    "Offence, violence",
    "Ofensiva, violencia",
    "Offensive, violence"
  ],
  [
    "Аналіз, моніторинг",
    "Analysis, monitoring",
    "Análisis, seguimiento",
    "Analyse, suivi"
  ],
  [
    "Мінімальна активність",
    "Minimal activity",
    "Actividad mínima",
    "Activité minimale"
  ],
  [
    "Ризиковані операції",
    "Risky operations",
    "Operaciones arriesgadas",
    "Opérations risquées"
  ],
  [
    "Поточні справи",
    "Current activities",
    "Actividades actuales",
    "Activités courantes"
  ],
  [
    "Старт операцій — найкращий день",
    "Starting operations — traditionally the best day",
    "Iniciar operaciones: tradicionalmente el mejor día",
    "Début des opérations : traditionnellement le meilleur jour"
  ],
  [
    "Лише оборона",
    "Defence only",
    "Solo defensa",
    "Défense uniquement"
  ],
  [
    "Будь-які активні дії",
    "Any active undertakings",
    "Cualquier acción activa",
    "Toute action active"
  ],
  [
    "Рішучі дії, дедлайни",
    "Decisive action, deadlines",
    "Acciones decididas, plazos",
    "Actions décisives, échéances"
  ],
  [
    "Відпочинок, ротація",
    "Rest, rotation",
    "Descanso, rotación",
    "Repos, rotation"
  ],
  [
    "Рутинні задачі",
    "Routine tasks",
    "Tareas rutinarias",
    "Tâches courantes"
  ],
  [
    "Важливі рішення",
    "Important decisions",
    "Decisiones importantes",
    "Décisions importantes"
  ],
  [
    "Наступ",
    "Offence",
    "Ofensiva",
    "Offensive"
  ],
  [
    "Переговори, дипломатія",
    "Negotiations, diplomacy",
    "Negociaciones, diplomacia",
    "Négociations, diplomatie"
  ],
  [
    "Духовна підготовка, мотивація",
    "Spiritual preparation, motivation",
    "Preparación espiritual, motivación",
    "Préparation spirituelle, motivation"
  ],
  [
    "Угоди, підписання",
    "Agreements, signing",
    "Acuerdos, firmas",
    "Accords, signatures"
  ],
  [
    "Будь-які справи — успіх",
    "Any activity — traditionally associated with success",
    "Cualquier actividad: tradicionalmente asociada con el éxito",
    "Toute activité : traditionnellement associée à la réussite"
  ],
  [
    "Аналіз, спостереження",
    "Analysis, observation",
    "Análisis, observación",
    "Analyse, observation"
  ],
  [
    "Важливі ініціативи",
    "Important initiatives",
    "Iniciativas importantes",
    "Initiatives importantes"
  ]
]);

NRLocale.register([
  [
    "несприятливий",
    "unfavourable",
    "desfavorable",
    "défavorable"
  ],
  [
    "несприятлива",
    "unfavourable",
    "desfavorable",
    "défavorable"
  ],
  [
    "Амавасья",
    "Amavasya",
    "Amavasya",
    "Amavasya"
  ],
  [
    "Нанда (радісна) — сприятлива для починань і нових справ.",
    "Nanda (joyful) — traditionally favourable for new beginnings and activities.",
    "Nanda (alegre): tradicionalmente favorable para nuevos comienzos y actividades.",
    "Nanda (joyeuse) : traditionnellement favorable aux nouveaux débuts et activités."
  ],
  [
    "Пурна (повна) — сприятлива для завершення і дипломатії.",
    "Purna (full) — traditionally favourable for completion and diplomacy.",
    "Purna (llena): tradicionalmente favorable para finalizar tareas y para la diplomacia.",
    "Purna (pleine) : traditionnellement favorable à l’achèvement et à la diplomatie."
  ],
  [
    "Креатив, лікування, HR, wellbeing",
    "Creativity, treatment, HR, wellbeing",
    "Creatividad, tratamiento, RR. HH., bienestar",
    "Créativité, traitement, RH, bien-être"
  ],
  [
    "Інтуїтивні рішення, аналітика, R&D",
    "Intuitive decisions, analysis, R&D",
    "Decisiones intuitivas, análisis, I+D",
    "Décisions intuitives, analyse, R&D"
  ],
  [
    "Виконання завдань, успіх у справах",
    "Completing tasks, success in activities",
    "Cumplir tareas, éxito en las actividades",
    "Accomplissement des tâches, réussite des activités"
  ],
  [
    "Відпочинок, рефлексія, ретро, стратегічне мислення",
    "Rest, reflection, retrospection, strategic thinking",
    "Descanso, reflexión, retrospectiva, pensamiento estratégico",
    "Repos, réflexion, rétrospection, réflexion stratégique"
  ],
  [
    "Сумарний astro-контекст підтримує",
    "Overall astronomical context is supportive",
    "El contexto astronómico general es favorable",
    "Le contexte astronomique global est favorable"
  ],
  [
    "але це не дозвіл і не заміна оперативного стану.",
    "but this is neither permission nor a substitute for the operational status.",
    "pero esto no es una autorización ni sustituye al estado operativo.",
    "mais cela ne constitue ni une autorisation ni un remplacement de l’état opérationnel."
  ],
  [
    "Краща дія: лише планові дії після перевірки оперативного стану й часових вікон.",
    "Suggested action: planned activities only, after checking the operational status and time windows.",
    "Acción sugerida: solo actividades planificadas, tras comprobar el estado operativo y las franjas horarias.",
    "Action suggérée : uniquement les activités prévues, après vérification de l’état opérationnel et des créneaux horaires."
  ],
  [
    "Аналіз, review, спостереження",
    "Analysis, review, observation",
    "Análisis, revisión, observación",
    "Analyse, revue, observation"
  ]
]);

NRLocale.register([["Обидва видання — PAC/IMD; це не незалежні джерела.", "Both publications are from PAC/IMD; these are not independent sources.", "Ambas publicaciones son de PAC/IMD; no son fuentes independientes.", "Les deux publications proviennent du PAC/IMD ; ces sources ne sont pas indépendantes."]]);

NRLocale.register([["Що змінилося?", "What changed?", "¿Qué cambió?", "Qu’est-ce qui a changé ?"], ["Сума до округлення", "Total before rounding", "Total antes del redondeo", "Total avant arrondi"], ["Прогноз добового максимуму Kp", "Forecast daily maximum Kp", "Máximo diario previsto de Kp", "Maximum quotidien prévu de Kp"], ["Порівняно з попереднім розрахунком, відкритим на цьому пристрої.", "Compared with the previous calculation viewed on this device.", "Comparado con el cálculo anterior visto en este dispositivo.", "Comparaison avec le calcul précédent consulté sur cet appareil."], ["Як пройшов ваш план?", "How did your plan go?", "¿Cómo fue tu plan?", "Comment s’est passé votre plan ?"], ["Підсумок уже збережено", "Outcome already saved", "Resultado ya guardado", "Résultat déjà enregistré"], ["Один дотик — запис у ваш щоденник. Вечір за Києвом.", "One tap saves to your journal. Evening in Kyiv.", "Un toque guarda el resultado en tu diario. Tarde en Kyiv.", "Un geste enregistre le résultat dans votre journal. Soirée à Kyiv."], ["Відкрити щоденник", "Open journal", "Abrir diario", "Ouvrir le journal"]]);

NRLocale.register([["Прогноз G · максимум: ", "G forecast · maximum: ", "Pronóstico G · máximo: ", "Prévision G · maximum : "], ["NOAA · попередження та ймовірності", "NOAA · alerts and probabilities", "NOAA · alertas y probabilidades", "NOAA · alertes et probabilités"]]);
NRLocale.register([["Kp СПОСТЕРЕЖЕННЯ","Kp OBSERVATION","Kp OBSERVADO","Kp OBSERVÉ"],["Kp ОЦІНКА NOAA","Kp NOAA ESTIMATE","Kp ESTIMACIÓN NOAA","Kp ESTIMATION NOAA"]]);

NRLocale.register([["Сума внесків ","Sum of contributions ","Suma de aportes ","Somme des contributions "],[" · шкала обмежена до "," · scale capped at "," · escala limitada a "," · échelle plafonnée à "],["Kp макс. ","Kp max ","Kp máx. ","Kp max "],[" · NOAA outlook від "," · NOAA outlook of "," · NOAA outlook del "," · NOAA outlook du "],[" · NOAA 3-годинний прогноз"," · NOAA 3-hour forecast"," · pronóstico NOAA de 3 horas"," · prévision NOAA sur 3 heures"],["Орієнтир · outlook NOAA від ","Outlook · NOAA issue of ","Orientación · NOAA del ","Repère · NOAA du "]]);
NRLocale.register([["випуск ","issued ","emitido ","émis le "]]);

NRLocale.register([["Сидерична · Лахірі", "Sidereal · Lahiri", "Sideral · Lahiri", "Sidéral · Lahiri"], ["Вара", "Vara", "Vara", "Vara"], ["Йога", "Yoga", "Yoga", "Yoga"], ["Карана", "Karana", "Karana", "Karana"], ["Шукла", "Shukla", "Shukla", "Shukla"], ["Крішна", "Krishna", "Krishna", "Krishna"]]);

// Reviewed consumer copy: W-08 and W-09.
NRLocale.register([["Оцінка експерта (має пріоритет над формулою)", "Expert assessment (takes priority over the formula)", "Valoración experta (tiene prioridad sobre la fórmula)", "Évaluation experte (prioritaire sur la formule)"], ["за київським часом", "Kyiv time", "hora de Kyiv", "heure de Kyiv"], ["SKYRHYTHM · КИЇВ", "SKYRHYTHM · KYIV", "SKYRHYTHM · KYIV", "SKYRHYTHM · KYIV"], ["Сума внесків збігається із сумою, збереженою в джерелі. Це перевірка арифметики; вона не підтверджує повноту переліку.", "The contributions add up to the sum saved in the source. This checks arithmetic, not whether the list is complete.", "Los aportes suman el total guardado en la fuente. Esto comprueba la aritmética, no que la lista esté completa.", "Les contributions correspondent à la somme enregistrée dans la source. Cela vérifie le calcul, pas si la liste est complète."], ["Сума внесків не збігається із сумою джерела або сума джерела відсутня; потрібна перевірка.", "The contributions do not match the source sum, or the source sum is missing; review is needed.", "Los aportes no coinciden con la suma de la fuente, o esta falta; se requiere revisión.", "Les contributions ne correspondent pas à la somme de la source, ou celle-ci manque ; une vérification est nécessaire."]]);

NRLocale.register([["місцевий час пристрою", "device local time", "hora local del dispositivo", "heure locale de l’appareil"], ["ДАНІ ПЕРЕХОДІВ НЕПОВНІ", "TRANSITION DATA INCOMPLETE", "DATOS DE TRANSICIONES INCOMPLETOS", "DONNÉES DE TRANSITION INCOMPLÈTES"], ["Недостатньо даних, щоб перелічити переходи цієї доби.", "Not enough data to list this day’s transitions.", "No hay datos suficientes para enumerar las transiciones de este día.", "Les données ne suffisent pas pour énumérer les transitions de cette journée."], ["Наступний перехід не підтверджено", "Next transition not confirmed", "Siguiente transición sin confirmar", "Transition suivante non confirmée"], ["цивільний день тижня", "civil weekday", "día de la semana civil", "jour civil de la semaine"], ["Не перевірено", "Unverified", "Sin verificar", "Non vérifié"]]);

NRLocale.register([["Назва дня та його традиційний управитель. Тут день змінюється опівночі за місцевим часом.", "The weekday and its traditional ruler. Here the day changes at local midnight.", "El día de la semana y su regente tradicional. Aquí el día cambia a medianoche local.", "Le jour de la semaine et son maître traditionnel. Ici, le jour change à minuit local."]]);

NRLocale.register([["ДОВІДКА, НЕ ДОДАНОК", "REFERENCE, NOT A CONTRIBUTION", "REFERENCIA, NO UN APORTE", "REPÈRE, PAS UNE CONTRIBUTION"], ["Tithi · Vara · Nakshatra · Yoga · Karana не входять в основну формулу", "Tithi · Vara · Nakshatra · Yoga · Karana are not part of the main formula", "Tithi · Vara · Nakshatra · Yoga · Karana no forman parte de la fórmula principal", "Tithi · Vara · Nakshatra · Yoga · Karana ne font pas partie de la formule principale"], ["Координація, моральний підйом", "Coordination, lifted spirits", "Coordinación, ánimo elevado", "Coordination, moral élevé"], ["панчанга нейтральна", "neutral panchanga context", "contexto panchanga neutro", "contexte panchanga neutre"], ["Пурніма (Повня)", "Purnima (Full Moon)", "Purnima (Luna llena)", "Purnima (Pleine Lune)"]]);

// Date-dependent calendar context; preserve all uncertainty qualifications.
NRLocale.register([["Оцінки немає", "No score available", "No hay puntuación", "Aucune note disponible"], ["Експертний календар · обмеження нових починань", "Expert calendar · restrictions on new starts", "Calendario experto · restricciones para nuevos comienzos", "Calendrier expert · restrictions sur les nouveaux projets"], ["Таніта Талі позначає цю дату блискавкою у календарі сприятливих днів.", "Tanita Tali marks this date with a lightning symbol in her calendar of favorable days.", "Tanita Tali marca esta fecha con un rayo en su calendario de días favorables.", "Tanita Tali marque cette date d’un éclair dans son calendrier des jours favorables."], ["У календарі: з ", "In the calendar: from ", "En el calendario: desde ", "Dans le calendrier : à partir de "], ["У календарі: до ", "In the calendar: until ", "En el calendario: hasta ", "Dans le calendrier : jusqu’à "], ["Часові межі в календарі не зазначені.", "The calendar does not specify time limits.", "El calendario no indica límites horarios.", "Le calendrier ne précise pas de limites horaires."], ["Часовий пояс джерела не підтверджений; ці години не перераховано для вашого місця.", "The source time zone is unconfirmed; these times have not been converted for your location.", "La zona horaria de la fuente no está confirmada; estas horas no se han convertido para tu ubicación.", "Le fuseau horaire de la source n’est pas confirmé ; ces heures ne sont pas converties pour votre lieu."], ["Дата в експертному календарі відрізняється від розрахункового правила Рікта. Тут показано саме авторську позначку.", "The expert calendar date differs from the computed Rikta rule. The author’s mark is shown here.", "La fecha del calendario experto difiere de la regla calculada de Rikta. Aquí se muestra la marca de la autora.", "La date du calendrier expert diffère de la règle calculée de Rikta. La marque de l’autrice est affichée ici."], ["Джерело та перевірка", "Source and verification", "Fuente y verificación", "Source et vérification"], ["PDF-сторінка", "PDF page", "página PDF", "page PDF"], ["Позначку та надруковану межу звірено з оригіналом. Відсутність позначки в інші дні не означає рекомендації починати справи.", "The mark and printed time limit were checked against the original. An absent mark on other dates is not a recommendation to start an activity.", "La marca y el límite horario impreso se cotejaron con el original. La ausencia de marca en otras fechas no recomienda iniciar una actividad.", "La marque et la limite horaire imprimée ont été comparées à l’original. L’absence de marque à une autre date ne recommande pas de commencer une activité."], ["Авторка календаря", "Calendar author", "Autora del calendario", "Autrice du calendrier"], ["Розрахунок позначки Рікта", "Calculated Rikta mark", "Marca calculada de Rikta", "Marque calculée de Rikta"], ["Алгоритм визначив позначку обмеження нових починань.", "The algorithm identified a mark restricting new starts.", "El algoritmo identificó una marca de restricción de nuevos comienzos.", "L’algorithme a identifié une marque limitant les nouveaux projets."], ["За правилом Рікта позначка на цю дату не визначена; це не загальна рекомендація починати справи.", "The Rikta rule did not identify a mark for this date; this is not a general recommendation to start activities.", "La regla de Rikta no identificó una marca para esta fecha; esto no es una recomendación general para iniciar actividades.", "La règle de Rikta n’a pas identifié de marque pour cette date ; ce n’est pas une recommandation générale de commencer des activités."], ["Розрахунок відрізняється від авторського календаря. У формулі збережено авторську позначку.", "The calculation differs from the author’s calendar. The formula retains the author’s mark.", "El cálculo difiere del calendario de la autora. La fórmula conserva su marca.", "Le calcul diffère du calendrier de l’autrice. La formule conserve sa marque."], ["Інші календарні фактори відсутні: однієї Рікта недостатньо для загального бала.", "Other calendar factors are missing: Rikta alone is insufficient for an overall score.", "Faltan otros factores del calendario: Rikta por sí sola no basta para una puntuación general.", "D’autres facteurs calendaires manquent : Rikta seule ne suffit pas à établir une note globale."], ["Межі та правило розрахунку", "Intervals and calculation rule", "Intervalos y regla de cálculo", "Intervalles et règle de calcul"], ["Інтервалів Рікта в цій цивільній добі немає.", "There are no Rikta intervals in this civil day.", "No hay intervalos de Rikta en este día civil.", "Il n’y a aucun intervalle de Rikta dans cette journée civile."], ["Сценарій для Києва. Рікта займає щонайменше 30% відліків світлої частини доби з кроком 15 хвилин. Межі вище розраховані, а не переписані з авторського календаря. Фізичну невизначеність не оцінено.", "Kyiv scenario. Rikta covers at least 30% of daylight samples taken every 15 minutes. The intervals above are calculated, not copied from the author’s calendar. Physical uncertainty has not been estimated.", "Escenario para Kyiv. Rikta cubre al menos el 30% de las muestras diurnas tomadas cada 15 minutos. Los intervalos anteriores se calculan, no se copian del calendario de la autora. No se ha estimado la incertidumbre física.", "Scénario pour Kyiv. Rikta couvre au moins 30 % des échantillons diurnes pris toutes les 15 minutes. Les intervalles ci-dessus sont calculés, et non copiés du calendrier de l’autrice. L’incertitude physique n’a pas été estimée."], ["Вага позначки −3 враховується лише один раз у повному наборі факторів. Відтворення авторських позначок не доводить точності прогнозу подій.", "The −3 mark weight is counted only once in the full factor set. Reproducing the author’s marks does not establish event prediction accuracy.", "El peso −3 de la marca se cuenta una sola vez en el conjunto completo de factores. Reproducir las marcas de la autora no demuestra precisión predictiva de acontecimientos.", "Le poids −3 de la marque est compté une seule fois dans l’ensemble des facteurs. Reproduire les marques de l’autrice ne démontre pas la précision des prévisions d’événements."]]);

// Shared Ukrainian terminology in the expanded Panchanga guide.
NRLocale.register([["Сидеричний зодіак · Лахірі","Sidereal zodiac · Lahiri","Zodiaco sideral · Lahiri","Zodiaque sidéral · Lahiri"],["Тітхі · місячний ритм","Tithi · lunar rhythm","Tithi · ritmo lunar","Tithi · rythme lunaire"],["Накшатра · характер дії","Nakshatra · character of activity","Nakshatra · carácter de la actividad","Nakshatra · caractère de l’activité"],["Йога · фон взаємодії","Yoga · interaction context","Yoga · contexto de interacción","Yoga · contexte d’interaction"],["Половина тітхі, тому протягом дня змінюється частіше.","Half a tithi, so it changes more often during the day.","La mitad de un tithi; por eso cambia más a menudo durante el día.","La moitié d’un tithi ; elle change donc plus souvent dans la journée."]]);
// Audit FP549 (L10N): visible strings left in Ukrainian in other languages.
NRLocale.register([['Перейти до основного контенту','Skip to main content','Ir al contenido principal','Aller au contenu principal'],['ДОБРОВІЛЬНО · ЛОКАЛЬНО','VOLUNTARY · LOCAL','VOLUNTARIO · LOCAL','VOLONTAIRE · LOCAL'],['Мій підсумок дня','My day summary','Mi resumen del día','Mon bilan du jour'],['Чотири оцінки вашого досвіду, особиста історія та окрема згода на експорт для дослідження.','Four ratings of your experience, a personal history and separate consent to export for research.','Cuatro valoraciones de tu experiencia, un historial personal y un consentimiento aparte para exportar con fines de investigación.','Quatre évaluations de votre expérience, un historique personnel et un consentement distinct à l’export pour la recherche.']]);
NRLocale.register([['Експертна оцінка має пріоритет над формулою джерела. Прогностичну точність щодо подій ще не підтверджено.','Expert assessment takes priority over the source formula. Predictive accuracy for events has not been established.','La valoración experta tiene prioridad sobre la fórmula de la fuente. La precisión predictiva de acontecimientos no está demostrada.','L’évaluation experte prime sur la formule de la source. La précision prédictive concernant les événements n’est pas établie.']]);

NRLocale.register([['Пурніма: не цього дня','Purnima: not this day','Purnima: no es este día','Purnima : pas ce jour']]);

// Audit FP549 (L10N-2): forecast journal, moon phase and rows missing from this fork (checked with details expanded).
NRLocale.register([["ЖУРНАЛ ПРОГНОЗІВ · ЛИШЕ ЦЕЙ ПРИСТРІЙ","FORECAST JOURNAL · THIS DEVICE ONLY","DIARIO DE PRONÓSTICOS · SOLO ESTE DISPOSITIVO","JOURNAL DES PRÉVISIONS · CET APPAREIL UNIQUEMENT"],["Прогноз до події, результат — після","Forecast before the event, outcome after","Pronóstico antes del evento, resultado después","Prévision avant l’événement, résultat après"],["Записів прогнозу:","Forecast records:","Registros de pronóstico:","Enregistrements de prévision :"],["із 3000","of 3000","de 3000","sur 3000"],["сегмент","segment","segmento","segment"],["Оцінених днів:","Rated days:","Días valorados:","Jours évalués :"],["Пар прогноз–результат:","Forecast–outcome pairs:","Pares pronóstico–resultado:","Paires prévision–résultat :"],["журнал майже заповнений","journal almost full","diario casi lleno","journal presque plein"],["видано","issued","emitido","émis"],["експертна правка","expert correction","corrección experta","correction experte"],["формула","formula","fórmula","formule"],["Немає завершених днів без результату.","No completed days without an outcome.","No hay días terminados sin resultado.","Aucun jour terminé sans résultat."],["Експорт журналу (JSON)","Export journal (JSON)","Exportar diario (JSON)","Exporter le journal (JSON)"],["Архівування","Archiving","Archivado","Archivage"],["1) Завантажте архів. 2) Після того як файл збережено, почніть новий сегмент. Прогнози без оцінки за останні 30 днів і майбутні дні переносяться з їхнім хешем; оцінки не видаляються. Ланцюжок продовжується від архіву.","1) Download the archive. 2) Once the file is saved, start a new segment. Unrated forecasts from the last 30 days and future days are carried over with their hash; ratings are not deleted. The chain continues from the archive.","1) Descarga el archivo. 2) Cuando el archivo esté guardado, inicia un nuevo segmento. Los pronósticos sin valoración de los últimos 30 días y los días futuros se trasladan con su hash; las valoraciones no se eliminan. La cadena continúa desde el archivo.","1) Téléchargez l’archive. 2) Une fois le fichier enregistré, commencez un nouveau segment. Les prévisions non évaluées des 30 derniers jours et les jours à venir sont reportées avec leur empreinte ; les évaluations ne sont pas supprimées. La chaîne reprend à partir de l’archive."],["1. Завантажити архів","1. Download archive","1. Descargar archivo","1. Télécharger l’archive"],["2. Архів збережено — почати новий сегмент","2. Archive saved — start a new segment","2. Archivo guardado — iniciar un nuevo segmento","2. Archive enregistrée — commencer un nouveau segment"],["Записи не редагуються; зміна вхідних даних створює нову ревізію. Модель:","Entries are not edited; a change in input data creates a new revision. Model:","Los registros no se editan; un cambio en los datos de entrada crea una nueva revisión. Modelo:","Les entrées ne sont pas modifiées ; un changement des données d’entrée crée une nouvelle révision. Modèle :"],["Збіг з експертом не доводить точність. Пари — матеріал для перевірки, а не підтвердження самі по собі. Час пристрою не має незалежної атестації.","Agreement with the expert does not prove accuracy. Pairs are material for checking, not confirmation in themselves. Device time has no independent attestation.","La coincidencia con el experto no demuestra precisión. Los pares son material de verificación, no una confirmación por sí mismos. La hora del dispositivo no tiene certificación independiente.","L’accord avec l’expert ne prouve pas la précision. Les paires sont des éléments à vérifier, pas une confirmation en soi. L’heure de l’appareil n’a pas d’attestation indépendante."],["Ланцюжок SHA-256 цілий.","SHA-256 chain intact.","Cadena SHA-256 íntegra.","Chaîne SHA-256 intacte."],["Ланцюжок пошкоджено — запис","Chain broken — entry","Cadena dañada — registro","Chaîne rompue — entrée"],["Журнал пошкоджено. Записи збережені без змін; пари не обчислюються.","Journal damaged. Entries are kept unchanged; pairs are not calculated.","Diario dañado. Los registros se conservan sin cambios; los pares no se calculan.","Journal endommagé. Les entrées sont conservées sans modification ; les paires ne sont pas calculées."],["Архів сформовано (SHA-256","Archive created (SHA-256","Archivo generado (SHA-256","Archive créée (SHA-256"],["Якщо журнал змінився після цього, крок 2 попросить завантажити архів знову.","If the journal changes after this, step 2 will ask you to download the archive again.","Si el diario cambia después, el paso 2 pedirá descargar el archivo de nuevo.","Si le journal change ensuite, l’étape 2 demandera de télécharger à nouveau l’archive."],["Ваша оцінка дня після події","Your rating of the day after the event","Tu valoración del día después del evento","Votre évaluation de la journée après l’événement"],["Примітка (необов’язково)","Note (optional)","Nota (opcional)","Note (facultatif)"],["Зберегти дані для відновлення","Save recovery data","Guardar datos de recuperación","Enregistrer les données de récupération"],["з’являться після завантаження актуальних даних","will appear once current data is loaded","aparecerán al cargar los datos actuales","apparaîtront après le chargement des données actuelles"],["Журнал доступний лише для читання в цьому браузері. Відкрийте захищену сторінку застосунку в оновленому браузері; експорт даних доступний.","The journal is read-only in this browser. Open the secure app page in an up-to-date browser; data export remains available.","El diario es de solo lectura en este navegador. Abre la página segura de la aplicación en un navegador actualizado; la exportación sigue disponible.","Le journal est en lecture seule dans ce navigateur. Ouvrez la page sécurisée dans un navigateur à jour ; l’export reste disponible."],["Експертна правка (PDF","Expert correction (PDF","Corrección experta (PDF","Correction experte (PDF"],["Точність щодо подій не підтверджена.","Accuracy for events has not been confirmed.","La precisión respecto a los acontecimientos no está confirmada.","La précision concernant les événements n’est pas confirmée."],["Karana · короткий ритм","Karana · short cycle","Karana · ciclo corto","Karana · cycle court"],["Tithi · місячний день","Tithi · lunar day","Tithi · día lunar","Tithi · jour lunaire"],["Nakshatra · стоянка Місяця","Nakshatra · lunar mansion","Nakshatra · mansión lunar","Nakshatra · demeure lunaire"],["Yoga · сума довгот","Yoga · sum of longitudes","Yoga · suma de longitudes","Yoga · somme des longitudes"],["Karana · півтітхі","Karana · half a tithi","Karana · medio tithi","Karana · demi-tithi"],["Vara · день тижня","Vara · weekday","Vara · día de la semana","Vara · jour de la semaine"],["Зовнішні календарі можуть показувати іншу тіхі, якщо рахують \"на момент запиту\" або \"опівночі\" (західна конвенція) — це методологічна різниця, не обов’язково помилка.","External calendars may show a different Tithi when calculated at the time of the request or at midnight (Western convention). This is a difference in method, not necessarily an error.","Otros calendarios pueden mostrar un Tithi distinto si calculan para el momento de la consulta o la medianoche (convención occidental). Es una diferencia de método, no necesariamente un error.","D’autres calendriers peuvent afficher un Tithi différent s’ils calculent au moment de la consultation ou à minuit (convention occidentale). Il s’agit d’une différence de méthode, pas nécessairement d’une erreur."],["Зовнішні календарі можуть показувати іншу тіхі, якщо рахують \"на момент запиту\" або \"опівночі\" (західна конвенція) — це методологічна різниця, не обов'язково помилка.","External calendars may show a different Tithi when calculated at the time of the request or at midnight (Western convention). This is a difference in method, not necessarily an error.","Otros calendarios pueden mostrar un Tithi distinto si calculan para el momento de la consulta o la medianoche (convención occidental). Es una diferencia de método, no necesariamente un error.","D’autres calendriers peuvent afficher un Tithi différent s’ils calculent au moment de la consultation ou à minuit (convention occidentale). Il s’agit d’une différence de méthode, pas nécessairement d’une erreur."],["Екадаші (11-й тіхі)","Ekadashi (11th Tithi)","Ekadashi (11.º Tithi)","Ekadashi (11e Tithi)"],["Час пристрою не збігається з часом джерела більш ніж на 5 хв. Перевірте годинник пристрою.","The device time differs from the source time by more than 5 min. Check the device clock.","La hora del dispositivo difiere de la de la fuente en más de 5 min. Revise el reloj del dispositivo.","L’heure de l’appareil diffère de celle de la source de plus de 5 min. Vérifiez l’horloge de l’appareil."],["Експертні рішення для цієї дати суперечать одне одному, тому оцінку не показано.","Expert decisions for this date contradict each other, so no score is shown.","Las decisiones expertas para esta fecha se contradicen, por lo que no se muestra puntuación.","Les décisions d’expert pour cette date se contredisent ; aucune note n’est affichée."]]);

// Navigation (owner review 01.11.2026): the Panchanga tab becomes «Небо» (sky scene + panchanga).
NRLocale.register([['Небо','Sky','Cielo','Ciel'],['Небо: панчанга й планети','Sky: panchanga and planets','Cielo: panchanga y planetas','Ciel : panchanga et planètes']]);
NRLocale.register([['КЛАСИЧНА ВЕРСІЯ','CLASSIC VERSION','VERSIÓN CLÁSICA','VERSION CLASSIQUE'],['Класичний вигляд','Classic layout','Diseño clásico','Présentation classique'],['Попередній інтерфейс SkyRhythm: ті самі бали, старе компонування.','The previous SkyRhythm interface: the same scores, the earlier layout.','La interfaz anterior de SkyRhythm: las mismas puntuaciones, el diseño anterior.','L’interface précédente de SkyRhythm : les mêmes scores, l’ancienne présentation.']]);

// Offline and service-worker state banners belong to the selected interface language.
NRLocale.register([
  [
    "⏳ ЗАВАНТАЖЕННЯ",
    "⏳ LOADING",
    "⏳ CARGANDO",
    "⏳ CHARGEMENT"
  ],
  [
    "Очікуємо дані. Рішення не показується як нейтральне до завершення перевірки.",
    "Waiting for data. The result is not shown as neutral until validation finishes.",
    "Esperando datos. El resultado no se muestra como neutro hasta finalizar la validación.",
    "En attente des données. Le résultat ne sera pas affiché comme neutre avant la fin de la validation."
  ],
  [
    "◷ ЗАСТАРІЛІ ДАНІ",
    "◷ OUTDATED DATA",
    "◷ DATOS DESACTUALIZADOS",
    "◷ DONNÉES PÉRIMÉES"
  ],
  [
    "Частина джерел повернула кешовані дані. Доступність поточного рішення визначається його джерелами та строком чинності.",
    "Some sources returned cached data. Availability of the current result depends on its sources and validity period.",
    "Algunas fuentes devolvieron datos en caché. La disponibilidad del resultado actual depende de sus fuentes y su período de validez.",
    "Certaines sources ont renvoyé des données en cache. La disponibilité du résultat actuel dépend de ses sources et de sa période de validité."
  ],
  [
    "⇣ ОФЛАЙН · ДАНІ З КЕШУ",
    "⇣ OFFLINE · CACHED DATA",
    "⇣ SIN CONEXIÓN · DATOS EN CACHÉ",
    "⇣ HORS LIGNE · DONNÉES EN CACHE"
  ],
  [
    "Канонічне рішення збережене на пристрої. Live G недоступний до відновлення мережі.",
    "The canonical result is saved on this device. Live G is unavailable until the connection returns.",
    "El resultado canónico está guardado en este dispositivo. Live G no está disponible hasta que vuelva la conexión.",
    "Le résultat canonique est enregistré sur cet appareil. Live G reste indisponible jusqu’au rétablissement de la connexion."
  ],
  [
    "— НЕМАЄ ДАНИХ",
    "— NO DATA",
    "— SIN DATOS",
    "— AUCUNE DONNÉE"
  ],
  [
    "Відсутність даних не трактується як нейтральний стан або нульове рішення.",
    "Missing data does not mean a neutral state or a zero result.",
    "La ausencia de datos no significa un estado neutro ni un resultado de cero.",
    "L’absence de données ne signifie ni un état neutre ni un résultat nul."
  ],
  [
    "! ПОМИЛКА ОНОВЛЕННЯ",
    "! UPDATE ERROR",
    "! ERROR DE ACTUALIZACIÓN",
    "! ERREUR DE MISE À JOUR"
  ],
  [
    "Оновлення не завершено. Застосунок не підмінює помилку синтетичним рішенням.",
    "The update did not finish. The app does not replace the error with a synthetic result.",
    "La actualización no terminó. La aplicación no sustituye el error por un resultado sintético.",
    "La mise à jour n’est pas terminée. L’application ne remplace pas l’erreur par un résultat synthétique."
  ],
  [
    "F РЕЗЕРВНИЙ КОНТЕКСТ",
    "F FALLBACK CONTEXT",
    "F CONTEXTO DE RESPALDO",
    "F CONTEXTE DE SECOURS"
  ],
  [
    "Резервний Kp позначено окремо; він не є перевіреним експертним рішенням.",
    "Fallback Kp is labelled separately; it is not a verified expert decision.",
    "El Kp de respaldo se indica por separado; no es una decisión experta verificada.",
    "Le Kp de secours est signalé séparément ; ce n’est pas une décision experte vérifiée."
  ],
  [
    "Дані з кешу",
    "Cached data",
    "Datos en caché",
    "Données en cache"
  ],
  [
    "хв тому",
    "min ago",
    "min atrás",
    "min auparavant"
  ],
  [
    "вік невідомий",
    "age unknown",
    "antigüedad desconocida",
    "ancienneté inconnue"
  ],
  [
    "перевірте з'єднання",
    "check your connection",
    "comprueba tu conexión",
    "vérifiez votre connexion"
  ]
]);
